# Exercise: Algorithm Deconstruction Challenge

[Instructions](https://ai.wethinkco.de/ai-software/ai-use-cases/exercises/exercise-code-algorithms/)

This contains the starter code for the **Task Manager** application used in the exercise. Code is available for three languages:

- [Java](java/TaskManager/README.md)
- [Python](python/TaskManager/README.md)
- [Javascript](javascript/TaskManager/README.md)

_Note that the starter code is by no means brilliant or optimized code. It is intentionally created to be improved with the application of the various AI prompts and techniques you are going to learn in this course._
