Exercise 1: Code Readability Improvement (Java)
Issues the AI should identify:

Difficult to understand
UserMgr, U, a, f, un, pw, em are cryptic. You can’t tell what they do without reading implementation.
Method a does 4 things: validation, duplicate check, create object, DB insert. No comments.
Better names
Before

After

Why

UserMgr

UserManager

Spell out abbreviations

U

User

Class names should be nouns

u_list

users or userList

list suffix is redundant, but clarity helps

a

registerUser

Describes intent

f

findUserByUsername

Describes intent

un, pw, em

username, password, email

Self-documenting

nu

newUser

Avoid cryptic vars

res

isSuccess

Boolean name should be a question

Break down complex sections
Method a should be split: validateUserInput(), isUsernameTaken(), saveUserToDatabase(). One method = one job.
Style/formatting issues
SQL string concatenation = SQL injection risk. Should use prepared statements.
No Javadoc on public methods.
Inconsistent spacing around operators.
if (data[i].active == true) → if (data[i].active) is cleaner.
Readability issues you might miss: The DB insert happens after adding to u_list. If DB fails, you have a user in memory but not in DB. AI should flag that as a logic bug, not just readability.