Step 1: Analyze the code for pattern opportunities
AI Prompt I’d use:

Code
I have this function with complex nested conditionals for calculating shipping costs.
1. What design pattern opportunities do you see?
2. Why is Strategy a good fit here vs just extracting functions?
3. What are the distinct algorithms/variations in this code?

calculateShippingCost function
------------------------------------------
// Shipping cost calculator with complex pricing rules
function calculateShippingCost(packageDetails, destinationCountry, shippingMethod) {
  const { weight, length, width, height } = packageDetails;
  let cost = 0;

  // Calculate base cost by shipping method
  if (shippingMethod === 'standard') {
    // Standard shipping calculations
    if (destinationCountry === 'USA') {
      cost = weight * 2.5;
    } else if (destinationCountry === 'Canada') {
      cost = weight * 3.5;
    } else if (destinationCountry === 'Mexico') {
      cost = weight * 4.0;
    } else {
      // International shipping
      cost = weight * 4.5;
    }

    // Add dimensional weight adjustment for standard shipping
    if (weight < 2 && (length * width * height) > 1000) {
      cost += 5.0; // Dimensional weight surcharge
    }
  } else if (shippingMethod === 'express') {
    // Express shipping calculations
    if (destinationCountry === 'USA') {
      cost = weight * 4.5;
    } else if (destinationCountry === 'Canada') {
      cost = weight * 5.5;
    } else if (destinationCountry === 'Mexico') {
      cost = weight * 6.0;
    } else {
      // International shipping
      cost = weight * 7.5;
    }

    // Express has different dimensional weight rules
    if ((length * width * height) > 5000) {
      cost += 15.0; // Large package surcharge
    }
  } else if (shippingMethod === 'overnight') {
    // Overnight shipping calculations
    if (destinationCountry === 'USA') {
      cost = weight * 9.5;
    } else if (destinationCountry === 'Canada') {
      cost = weight * 12.5;
    } else {
      // Overnight not available for other countries
      return "Overnight shipping not available for this destination";
    }
  }

  return cost.toFixed(2);
}

// Example usage
const package = { weight: 5, length: 10, width: 10, height: 10 };
console.log(calculateShippingCost(package, 'USA', 'standard'));  // "12.50"
console.log(calculateShippingCost(package, 'Canada', 'express')); // "27.50"

-------------
1 line hidden
What AI should identify:

Pattern opportunity: Strategy. You have 3+ algorithms for calculateShippingCost that vary by shippingMethod: standard, express, overnight. Each has its own pricing table + rules.
Why Strategy vs extract functions: If you just extract calculateStandard(), calculateExpress(), you still have a switch in the main function. Every new shipping method = edit main function. Violates Open/Closed Principle. Strategy lets you add new methods without touching existing code.
Distinct variations:
StandardShippingStrategy: base rates + dimensional weight if < 2kg and volume > 1000
ExpressShippingStrategy: higher base rates + dimensional weight if volume > 5000
OvernightShippingStrategy: highest rates, limited countries, no dimensional rules
Step 2: Get implementation guidance for Strategy
AI Prompt:

Code
I want to refactor this shipping calculator to use the Strategy pattern.
1. Show me the interface/contract each strategy should implement
2. How do I select the right strategy at runtime?
3. Refactor this code to use Strategy, keeping the exact same behavior
4. How do I test each strategy in isolation?
Step 3: Refactor the code to implement Strategy
Refactored with Strategy pattern:

JavaScript
// 1. Strategy interface - all strategies implement this
class ShippingStrategy {
  /**
   * @param {object} packageDetails { weight, length, width, height }
   * @param {string} destinationCountry
   * @returns {number|string} cost or error message
   */
  calculate(packageDetails, destinationCountry) {
    throw new Error('calculate() must be implemented');
  }
}

// 2. Concrete strategies - one per shipping method
class StandardShippingStrategy extends ShippingStrategy {
  calculate({ weight, length, width, height }, destinationCountry) {
    let cost = 0;
    const rates = { USA: 2.5, Canada: 3.5, Mexico: 4.0 };
    cost = weight * (rates[destinationCountry] || 4.5); // default international

    // Dimensional weight surcharge
    if (weight < 2 && (length * width * height) > 1000) {
      cost += 5.0;
    }
    return cost;
  }
}

class ExpressShippingStrategy extends ShippingStrategy {
  calculate({ weight, length, width, height }, destinationCountry) {
    const rates = { USA: 4.5, Canada: 5.5, Mexico: 6.0 };
    let cost = weight * (rates[destinationCountry] || 7.5); // default international

    // Large package surcharge
    if ((length * width * height) > 5000) {
      cost += 15.0;
    }
    return cost;
  }
}

class OvernightShippingStrategy extends ShippingStrategy {
  calculate({ weight }, destinationCountry) {
    const rates = { USA: 9.5, Canada: 12.5 };
    if (!(destinationCountry in rates)) {
      return "Overnight shipping not available for this destination";
    }
    return weight * rates[destinationCountry];
  }
}

// 3. Context - holds a strategy and delegates to it
class ShippingCalculator {
  constructor() {
    this.strategies = {
      standard: new StandardShippingStrategy(),
      express: new ExpressShippingStrategy(),
      overnight: new OvernightShippingStrategy()
    };
  }

  calculateShippingCost(packageDetails, destinationCountry, shippingMethod) {
    const strategy = this.strategies[shippingMethod];
    if (!strategy) throw new Error(`Unknown shipping method: ${shippingMethod}`);

    const result = strategy.calculate(packageDetails, destinationCountry);
    return typeof result === 'number'? result.toFixed(2) : result;
  }
}

// 4. Usage - same API as before
const calculator = new ShippingCalculator();
const pkg = { weight: 5, length: 10, width: 10, height: 10 };
console.log(calculator.calculateShippingCost(pkg, 'USA', 'standard')); // "12.50"
console.log(calculator.calculateShippingCost(pkg, 'Canada', 'express')); // "27.50"

69 lines hidden
Step 4: Write tests to verify behavior preserved
Key principle: Test each strategy alone + test the context.

JavaScript
// Test each strategy in isolation
describe('StandardShippingStrategy', () => {
  const strategy = new StandardShippingStrategy();
  const pkg = { weight: 5, length: 10, width: 10, height: 10 };

  test('USA rate', () => {
    expect(strategy.calculate(pkg, 'USA')).toBe(12.5); // 5 * 2.5
  });

  test('dimensional weight surcharge', () => {
    const smallLightPkg = { weight: 1, length: 20, width: 10, height: 10 }; // volume 2000 > 1000
    expect(strategy.calculate(smallLightPkg, 'USA')).toBe(7.5); // 1*2.5 + 5
  });
});

describe('OvernightShippingStrategy', () => {
  const strategy = new OvernightShippingStrategy();

  test('unavailable country returns error', () => {
    const result = strategy.calculate({ weight: 5 }, 'Mexico');
    expect(result).toBe("Overnight shipping not available for this destination");
  });
});

// Test context + regression tests from original
describe('ShippingCalculator', () => {
  const calculator = new ShippingCalculator();
  const pkg = { weight: 5, length: 10, width: 10, height: 10 };

  test('maintains original behavior: standard USA', () => {
    expect(calculator.calculateShippingCost(pkg, 'USA', 'standard')).toBe("12.50");
  });

  test('maintains original behavior: express Canada', () => {
    expect(calculator.calculateShippingCost(pkg, 'Canada', 'express')).toBe("27.50");
  });
});

32 lines hidden
Run tests: behavior identical to original

Step 5: Document benefits gained
Before Strategy

After Strategy

1 function, 40 lines, 4 levels nesting

1 context + 3 strategy classes, each 10-15 lines

Add ground shipping = edit main function

Add GroundShippingStrategy, register in context. Zero changes to existing code

Can't unit test USA rates without hitting Mexico logic

StandardShippingStrategy tested alone

Cyclomatic complexity ∼12

Per class ∼3

if/else if chain grows forever

Map lookup this.strategies[shippingMethod]

Key benefit: Open/Closed Principle. Open for extension: add DroneShippingStrategy. Closed for modification: StandardShippingStrategy never changes when you add drone.

Reflection Questions
1. How did implementing the pattern improve maintainability?
Before: 40-line function with nested conditionals. To add “Economy” shipping I’d add another else if and risk breaking overnight logic. After: I create one new class. The PR diff shows only additions, no modifications to existing strategies. Code review is 5 minutes vs 30 minutes tracing if branches.

2. What future changes will be easier because of this pattern?

New shipping methods: drop in a new strategy class. 2. A/B testing pricing: swap StandardShippingStrategy for StandardShippingV2Strategy at runtime. 3. Per-customer discounts: decorate strategies without changing them.
3. Were there any unexpected challenges implementing the pattern?
Yes. The original returns a string error for overnight unavailable countries, but number for success. That forces the context to check typeof result. A better refactor would make all strategies return {cost: number, error?: string} so the return type is consistent. Patterns expose bad APIs you didn’t notice before.

Why Strategy vs Factory here?
Factory decides which object to create. Strategy decides which algorithm to run. Shipping is about swapping algorithms, not creating complex objects, so Strategy fits. If we had new StandardShippingLabel(), new ExpressShippingLabel() with different constructors, that’d be Factory.