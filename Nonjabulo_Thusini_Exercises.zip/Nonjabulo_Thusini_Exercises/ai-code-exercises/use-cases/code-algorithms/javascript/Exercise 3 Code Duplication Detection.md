Exercise 3: Code Duplication Detection (JavaScript)
Repeated patterns:

Average calculation: same for loop 3 times, only property changes: age, income, score
Max calculation: same for loop 3 times, only property changes
Ways to eliminate duplication:

Option 1: Helper functions, still junior-friendly


Option 2: reduce + dynamic keys, more DRY but harder for juniors


Benefits of refactoring:

Bug fix in one place: If userData.length === 0, original code divides by zero 3 times. Refactored fixes once.
Add new field like height: add 1 line vs 10 lines.
Reduces code from ∼45 lines to ∼15.
Most readable for juniors: Option 1. Explicit loops and helper names beat reduce and ...spread for people new to JS. That’s the tradeoff AI should explain.

Reflection Questions - sample answers for your doc
1. Which prompting strategy did you find most useful? Why?
Function Refactoring, because process_orders was overwhelming. Breaking it into validate_order and calculate_order_totals made me see how to think in small pieces.

2. What kinds of improvements did the AI suggest that you might not have thought of?
For Java: flagging SQL injection risk in the string concat. I was focused on names and missed security. For JS: using Math.max(...map()) instead of a manual loop.

3. Were there any suggestions you disagreed with? Why?
AI might suggest reduce() for everything in JS. I disagree for junior teams because it hurts readability. Explicit loops are slower to write but faster to debug when you’re learning.

4. How might you adapt these prompts for your specific codebase?
Add “Team coding standards: camelCase, max function length 20 lines” to Prompt 1. Add “We use pytest, so show refactored code with pytest fixtures” to Prompt 2.

5. What safeguards before applying AI-suggested refactoring to production?
From the chapter: “Remember to always have tests in place before refactoring”. So: 1. Write tests for existing behavior, 2. Run tests after refactor, 3. Code review with teammate, 4. Check performance if loops changed.


