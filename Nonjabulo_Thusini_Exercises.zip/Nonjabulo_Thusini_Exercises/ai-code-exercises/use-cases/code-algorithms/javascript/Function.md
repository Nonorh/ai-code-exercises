Step 1: Identify the distinct responsibilities in validateUserData
Running the "Function Refactoring" prompt on this 200-line monster, here’s what I’d tell the AI and what it should identify:

Current responsibilities in one function:

Orchestration: Decides registration vs profile update flow, manages errors array
Required field validation: Loops over different required field lists
Username validation: Length, charset, uniqueness check
Password validation: 5 separate regex rules + confirmation match
Email validation: Format + uniqueness check
Date of birth validation: Parse, future check, min age 13, max age 120
Address validation: Object vs string, required subfields, country-specific zip codes
Phone validation: Basic regex
Custom validation: Loop over options.customValidations
That’s 9 jobs. The “one screen rule” says if you scroll, it’s too big. This is 4 screens.

Step 2: Create a decomposition plan
Decomposition strategy: Extract by domain, not by step
Don’t make validateStep1, validateStep2. Make validateUsername, validatePassword. Each helper owns one business rule.

Planned helpers:

Helper

Input

Output

Reusable?

getRequiredFields(isRegistration)

boolean

string[]

Yes, config

validateRequiredFields(data, fields)

object, string[]

string[] errors

Yes

validateUsername(username, checkExisting)

string, obj

string[] errors

Yes, login flow

validatePassword(pw, confirmPw)

string, string

string[] errors

Yes, change pw flow

validateEmail(email, isReg, checkExisting)

string, bool, obj

string[] errors

Yes

validateDateOfBirth(dob)

string

string[] errors

Yes, other forms

validateAddress(addr)

obj/string

string[] errors

Yes, checkout flow

validatePhone(phone)

string

string[] errors

Yes

runCustomValidations(data, validations)

obj, array

string[] errors

Yes

Step 3: Extract helper functions with clear names and purposes
JavaScript
const MIN_USERNAME_LEN = 3;
const MAX_USERNAME_LEN = 20;
const MIN_PASSWORD_LEN = 8;
const MIN_AGE = 13;
const MAX_AGE = 120;

function getRequiredFields(isRegistration) {
  return isRegistration
   ? ['username', 'email', 'password', 'confirmPassword']
    : ['firstName', 'lastName', 'dateOfBirth', 'address'];
}

function validateRequiredFields(userData, requiredFields, isRegistration) {
  const errors = [];
  for (const field of requiredFields) {
    const value = userData[field];
    const isEmpty =!value || (typeof value === 'string' && value.trim() === '');
    if (isEmpty) {
      const msg = isRegistration
       ? `${field} is required for registration`
        : `${field} cannot be empty if provided`;
      errors.push(msg);
    }
  }
  return errors;
}

function validateUsername(username, checkExisting) {
  const errors = [];
  if (!username) return errors;

  if (username.length < MIN_USERNAME_LEN) {
    errors.push(`Username must be at least ${MIN_USERNAME_LEN} characters long`);
  } else if (username.length > MAX_USERNAME_LEN) {
    errors.push(`Username must be at most ${MAX_USERNAME_LEN} characters long`);
  } else if (!/^[a-zA-Z0-9_]+$/.test(username)) {
    errors.push('Username can only contain letters, numbers, and underscores');
  } else if (checkExisting?.usernameExists(username)) {
    errors.push('Username is already taken');
  }
  return errors;
}

function validatePassword(password, confirmPassword) {
  const errors = [];
  if (!password) return errors;

  if (password.length < MIN_PASSWORD_LEN) {
    errors.push(`Password must be at least ${MIN_PASSWORD_LEN} characters long`);
  }
  if (!/[A-Z]/.test(password)) errors.push('Password must contain at least one uppercase letter');
  if (!/[a-z]/.test(password)) errors.push('Password must contain at least one lowercase letter');
  if (!/[0-9]/.test(password)) errors.push('Password must contain at least one number');
  if (!/[^A-Za-z0-9]/.test(password)) errors.push('Password must contain at least one special character');
  if (confirmPassword!== undefined && confirmPassword!== password) {
    errors.push('Password and confirmation do not match');
  }
  return errors;
}

function validateEmail(email, isRegistration, checkExisting) {
  const errors = [];
  if (email === undefined) return errors;

  if (email.trim() === '') {
    if (isRegistration) errors.push('Email is required');
    return errors;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    errors.push('Email format is invalid');
  } else if (checkExisting?.emailExists(email)) {
    errors.push('Email is already registered');
  }
  return errors;
}

function validateDateOfBirth(dobString) {
  const errors = [];
  if (!dobString) return errors;

  const dobDate = new Date(dobString);
  if (isNaN(dobDate.getTime())) {
    errors.push('Date of birth is not a valid date');
    return errors;
  }

  const now = new Date();
  const minAgeDate = new Date(now.getFullYear() - MIN_AGE, now.getMonth(), now.getDate());
  const maxAgeDate = new Date(now.getFullYear() - MAX_AGE, now.getMonth(), now.getDate());

  if (dobDate > now) errors.push('Date of birth cannot be in the future');
  else if (dobDate > minAgeDate) errors.push(`You must be at least ${MIN_AGE} years old`);
  else if (dobDate < maxAgeDate) errors.push(`Invalid date of birth (age > ${MAX_AGE} years)`);
  return errors;
}

// validateAddress, validatePhone, runCustomValidations follow same pattern...

94 lines hidden
Step 4: Refactor the main function to call helpers
JavaScript
function validateUserData(userData, options = {}) {
  const isRegistration = options.isRegistration || false;
  const requiredFields = getRequiredFields(isRegistration);

  const allErrors = [
   ...validateRequiredFields(userData, requiredFields, isRegistration),
   ...validateUsername(userData.username, options.checkExisting),
   ...validatePassword(userData.password, userData.confirmPassword),
   ...validateEmail(userData.email, isRegistration, options.checkExisting),
   ...validateDateOfBirth(userData.dateOfBirth),
   ...validateAddress(userData.address),
   ...validatePhone(userData.phone),
   ...runCustomValidations(userData, options.customValidations)
  ];

  return allErrors;
}

12 lines hidden
Main function is now 12 lines. It reads like a checklist. Each helper is 10-20 lines and does one thing.

Step 5: Run tests to verify behavior preserved
Key test cases to write BEFORE refactoring:

Registration missing username → error "username is required for registration"
Username ab → error "at least 3 characters"
Password abc123 → errors for uppercase, special char
DOB 2050-01-01 → error "cannot be in the future"
US address with zip ABC → error "Invalid US ZIP code"
After refactor, all tests should still pass. If one fails, you know which helper broke.

Step 6: Document approach and benefits
Refactoring approach:

Used "Function Refactoring" prompt to list 9 responsibilities
Grouped by domain: username, password, email, etc, not by execution order
Extracted pure functions that take data, return string[]. No side effects = easy to unit test
Main function becomes orchestration only: call helpers, concat arrays
Benefits gained:

Readability: Main function fits on one screen. New dev can understand flow in 10 seconds.
Maintainability: Need to change password rules? Edit validatePassword only. 15 lines vs 200.
Testability: Can test validateUsername('ab') in isolation without mocking userData object
Reusability: validateEmail can be used in "forgot password" flow. Before it was trapped inside 200 lines.
Bug isolation: If zip code regex is wrong, stack trace points to validateAddress, not line 147 of mega-function.
Reflection Questions - sample answers for your doc
1. How did breaking down the function improve its readability and maintainability?
Before: 200 lines, 8 levels of nesting. To change min password length I had to Ctrl+F and hope I found all spots. After: Main function is a table of contents. MIN_PASSWORD_LEN is a constant at top. Change takes 5 seconds and I’m confident I didn’t miss anything. Cyclomatic complexity dropped from ∼25 to ∼3 per function.

2. What was the most challenging part of decomposing the function?
Deciding boundaries. validateEmail also checks checkExisting.emailExists. Should that be separate? I decided yes, pass checkExisting in, because “format” and “uniqueness” are both email concerns. But you could argue uniqueness is a service call, not validation. The AI prompt helped by asking “what are the different responsibilities” which forced me to name them.

3. Which extracted function would be most reusable in other contexts?
validatePassword and validateEmail. Every app has login, password reset, profile update. validateAddress is also reusable for checkout, shipping. validateRequiredFields is the most generic - you could use it for any form.