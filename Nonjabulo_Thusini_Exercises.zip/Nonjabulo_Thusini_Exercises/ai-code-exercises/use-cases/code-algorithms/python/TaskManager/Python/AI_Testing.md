Part 1: Understanding What to Test

Exercise 1.1: Behavior Analysis

What the function does: Takes a task object and returns a numeric score. Higher score = higher priority. It uses 5 factors:

Base priority: LOW=10, MEDIUM=20, HIGH=40, URGENT=60 points
Due date: Overdue +35, due today +20, due ≤2 days +15, due ≤7 days +10
Status penalty: DONE -50, REVIEW -15
Tag boost: +8 if tags contain "blocker", "critical", or "urgent"
Recent update boost: +5 if updated less than 1 day ago
5+ test cases including edge cases:

Test Case

Why It Matters

URGENT task, no due date, status=TODO
Verifies base priority calculation works

MEDIUM task overdue by 1 day
Checks days_until_due < 0 branch

HIGH task due today
Checks days_until_due == 0 branch

LOW task with status=DONE
Ensures penalty makes DONE tasks sink to bottom

Task with tag="blocker"
Verifies tag boost logic

Task with due_date=None
Edge case: code should not crash, due date logic skipped

Task with priority=None
Edge case: priority_weights.get() defaults to 0

Task updated 30 seconds ago
Edge case: < 1 days should include same-day updates

Task due in exactly 2 days vs 3 days
Boundary: checks <= 2 vs <= 7 cutoff

Which test first and why: Start with #1 “URGENT task, no due date”. It tests the simplest happy path with no branching logic. If that fails, nothing else will work.
-----------------------------------------------------------------------------------
Exercise 1.2: Test Planning
Test plan for all 3 functions:

Priority of test cases:

P0: calculate_task_score unit tests: Core logic. If scores are wrong, sorting is wrong.
P1: sort_tasks_by_importance integration: Verifies scores are used correctly to sort.
P2: get_top_priority_tasks limit behavior: Checks slicing and empty list edge cases.
Types of tests needed:

Unit tests: calculate_task_score with mocked task objects for each factor
Integration tests: sort_tasks_by_importance with 3-4 real task objects, verify order
Edge case tests: Empty list to sort_tasks_by_importance, limit > len(tasks) to get_top_priority_tasks
Checklist:

 Base priority scores correct for all 4 levels
 Due date buckets: overdue, today, 2 days, 7 days, 8 days, None
 Status penalties applied for DONE and REVIEW
 Tag boost for "blocker", "critical", "urgent". No boost for other tags
 Recent update boost for <1 day, no boost for ≥1 day
 Sort returns highest score first
 get_top_priority_tasks returns exactly limit items or fewer
 Functions handle empty input list
Part 2: Improving a Single Test
Exercise 2.1: Basic test improved
Before, simple test:

Python
def test_basic():
    task = Task(priority=HIGH)
    assert calculate_task_score(task) > 0
Problems: Tests implementation detail "greater than 0", not behavior. Unclear intent. No due date/status/tags set, so it’s ambiguous.

After, improved:

Python
def test_high_priority_task_without_modifiers_gets_base_score():
    # Given: A task with HIGH priority and no other scoring factors
    task = Task(
        priority=TaskPriority.HIGH,
        due_date=None,
        status=TaskStatus.TODO,
        tags=[],
        updated_at=datetime.now() - timedelta(days=2)
    )
    # When: We calculate the score
    score = calculate_task_score(task)
    # Then: Score should be HIGH base of 4 * 10 = 40
    assert score == 40

8 lines hidden
Why better: Tests behavior "HIGH priority = 40 base points". Clear Given/When/Then. Precise assertion. Controls all other factors.
----------------------------------------------------------------------------------
Exercise 2.2: Due date calculation test
Principle: Good tests for date math should cover boundaries and timezones. Test each branch.

Better test example:

Python
def test_overdue_task_gets_large_score_boost():
    # Given: A task that was due yesterday
    yesterday = datetime.now() - timedelta(days=1)
    task = Task(priority=TaskPriority.LOW, due_date=yesterday, status=TaskStatus.TODO)

    # When: Score is calculated
    score = calculate_task_score(task)

    # Then: Score includes LOW base 10 + overdue boost 35 = 45
    assert score == 45

5 lines hidden
Comments: This isolates the days_until_due < 0 branch. Uses a fixed relative date so test doesn’t break tomorrow.

Edge cases to add:

Due in exactly 2 days vs 3 days to test <= 2 boundary
due_date=None to ensure no crash
Mock datetime.now() to avoid flaky tests
Part 3: Test-Driven Development Practice
----------------------------------------------------------------------
Exercise 3.1: TDD for new feature "+12 for current user"
1. First test, why: Test the new behavior in isolation.

Python
def test_task_assigned_to_current_user_gets_score_boost():
    task = Task(priority=TaskPriority.LOW, assigned_to="me")
    score = calculate_task_score(task, current_user="me")
    assert score == 10 + 12 # LOW base + boost
2. Minimal code to pass: Add param and if task.assigned_to == current_user: score += 12
3. Next test: Task assigned to someone else gets no boost.
4. Refactor vs new functionality: Refactor only after all tests for the feature pass.
----------------------------------------------------------------------------
Exercise 3.2: TDD for bug fix
The prompt mentions .days vs milliseconds bug. Python datetime already uses .days, so no bug here. But if there were:

1. Test to reproduce bug:

Python
def test_days_since_update_uses_days_not_seconds():
    # Updated 25 hours ago = 1 day, not 0
    task = Task(updated_at=datetime.now() - timedelta(hours=25))
    score = calculate_task_score(task)
    # Should NOT get the +5 boost because days_since_update = 1
    assert score == base_score_only

1 line hidden
2. Fix: Ensure we use .days not .total_seconds() / 86400 with rounding errors.

Part 4: Integration Testing
Exercise 4.1: Full workflow test
Scenario to verify: Tasks are scored, then sorted, then top N returned.

Test data design:

Python
def test_full_workflow_sorts_and_limits_correctly():
    tasks = [
        Task(id=1, priority=LOW, due_date=next_week), # Score ~20
        Task(id=2, priority=URGENT, due_date=yesterday), # Score ~60+35=95
        Task(id=3, priority=MEDIUM, status=DONE), # Score ~20-50=-30
    ]
    top_2 = get_top_priority_tasks(tasks, limit=2)

    assert len(top_2) == 2
    assert top_2[0].id == 2 # Highest score first
    assert top_2[1].id == 1 # Second highest

6 lines hidden
Assertions: Check length, order, and that DONE task is excluded from top results. This exercises all 3 functions.