Exercise : Codebase Exploration Challenge

Exercise Part 1: Understanding a Specific Feature

Code Understanding Journal

Feature Chosen:
Task Creation and Status Updates

Main Components Involved:

* cli.py – receives user commands.
* task_manager.py – coordinates task operations.
* models.py – defines the Task object and status values.
* storage.py – saves and loads task data.

Execution Flow

Creating a Task

1. User enters task information through the command line.
2. cli.py receives the input.
3. task_manager.py creates a new Task object.
4. storage.py stores the task in memory.
5. save() writes the task to tasks.json.

Updating a Task Status

1. User selects a task.
2. task_manager.py retrieves the task.
3. The Task status is updated.
4. storage.py saves the updated task.
5. Changes are written to tasks.json.

Data Storage

Tasks are stored in a JSON file called tasks.json.

TaskEncoder converts Task objects into JSON format.

TaskDecoder converts JSON data back into Task objects.

Interesting Design Patterns:

* Separation of concerns:

  * cli.py handles user interaction.
  * task_manager.py handles business logic.
  * storage.py handles persistence.
* Object-oriented design through the Task class.

-----------------------------------------------------------

Exercise Part 2: Deepen Understanding Through Guided Questions

Initial Understanding:

I initially believed task priority was simply a value attached to each task.

Further Investigation:

After examining the code, I discovered that TaskPriority is treated as a separate domain concept and is used when filtering and organizing tasks.

Guided Questions:

Question: What determines the importance of a task?

Answer: TaskPriority.

Question: Where is priority information stored?

Answer: Within each Task object.

Question: How are tasks grouped by priority?

Answer: Through methods that filter tasks according to their priority level.

Key Insights:

* Priority is part of the domain model.
* Priority influences how tasks are displayed and filtered.
* Priority information is persisted in JSON storage.

Misconceptions Corrected:

I originally thought priority only affected display order. Further investigation showed it is also used in filtering and task management operations.

---------------------------------------------------------------

Exercise Part 3: Mapping Data Flow:

Feature Investigated:

Marking a Task as Complete

Data Flow Diagram:

User
↓
cli.py
↓
task_manager.py
↓
Task Object
↓
storage.py
↓
tasks.json

State Changes:

Before completion:

Task Status = Pending

After completion:

Task Status = Completed

Completion timestamp may also be recorded.

Potential Points of Failure:

* Invalid task ID.
* Task not found.
* JSON file corruption.
* Save operation failure.

Persistence Process:

1. Status changes in the Task object.
2. storage.py calls save().
3. TaskEncoder converts the object to JSON.
4. Updated data is written to tasks.json.

-------------------------------------------------------

Exercise Part 4: Reflection and Presentation

Application Architecture:

The application follows a layered structure:

* Presentation Layer: cli.py
* Business Logic Layer: task_manager.py
* Domain Layer: models.py
* Persistence Layer: storage.py

Key Features Studied:

1. Task Creation
2. Task Prioritization
3. Task Completion

Most Interesting Design Choice:

The use of TaskEncoder and TaskDecoder to handle conversion between Python objects and JSON data.

Biggest Challenge:

Understanding how information moves between multiple files.

How AI Helped:

AI helped identify relationships between components, explain execution flow, and validate my understanding of the codebase.

------------------------------------------------------------------
Final Reflection:

Initial Understanding:

At first, I only understood the project through file names.

Final Understanding:

I now understand how tasks are created, updated, stored, retrieved, prioritized, and completed.

Most Valuable Insight:

Understanding how storage.py manages persistence using JSON and custom encoders/decoders.

Future Strategy:

When approaching an unfamiliar codebase, I will:

1. Examine the project structure.
2. Identify core entities.
3. Trace data flow between components.
4. Use AI prompts to validate understanding.
5. Document findings in a journal.

