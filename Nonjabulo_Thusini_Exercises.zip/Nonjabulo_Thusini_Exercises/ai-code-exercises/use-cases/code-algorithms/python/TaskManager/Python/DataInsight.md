1) Prompt 1 — Comprehensive README.md

markdown
DataInsight

DataInsight is a data analysis and visualization framework for scientific data. It gives you a consistent Python API to import messy data from CSV, Excel, SQL, or APIs, clean and transform it with Pandas, run statistical analysis, build interactive Plotly charts, and export publication-ready reports.

Features

- Data import from various sources: CSV, Excel, SQL databases, and REST APIs
- Data cleaning and transformation tools: handle missing values, outliers, type conversion, joins
- Statistical analysis functions: descriptive stats, correlations, t-tests, ANOVA
- Interactive visualizations: Matplotlib for static plots, Plotly for interactive dashboards
- Report generation: export notebooks to HTML or PDF with embedded charts
- Export capabilities: CSV, Excel, JSON, Parquet

Technologies Used

Python 3.8+, Pandas, NumPy, Matplotlib, Plotly, Jupyter, SQLAlchemy

Installation

Prerequisites
- Python 3.8 or higher
- pip
- (optional) virtualenv

Quick Install
bash
git clone https://github.com/yourusername/datainsight.git
cd datainsight

python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

pip install -r requirements.txt

Requirements include pandas>=1.5, numpy, matplotlib, plotly, jupyter, sqlalchemy, openpyxl

Basic Usage

python
import datainsight as di

1. Import
df = di.io.read_csv("data/experiment.csv")

2. Clean
df = di.transform.fill_missing(df, strategy="mean")
df = di.transform.remove_outliers(df, column="temperature")

3. Analyze
summary = di.analysis.describe(df)
corr = di.analysis.correlation(df)

4. Visualize
fig = di.viz.scatter_interactive(df, x="time", y="temperature", color="group")
fig.show()

5. Report
di.report.to_html(df, summary, fig, output="report.html")

Run the examples:
bash
jupyter notebook examples/01_quickstart.ipynb

Configuration Options

Create `~/.datainsight/config.ini` or set env vars:

| Option | Default | Description |
|--------|---------|-------------|
| `DI_PLOTLY_THEME` | plotly_white | Default Plotly template |
| `DI_CACHE_DIR` | ~/.datainsight/cache | Cache for API calls |
| `DI_SQL_TIMEOUT` | 30 | SQL query timeout in seconds |

Set in code:
python
di.set_config(plotly_theme="plotly_dark")

Code Structure Overview

/datainsight - Main package
  /io - Data import/export modules
  /transform - Data cleaning tools
  /analysis - Statistical algorithms
  /viz - Visualization tools
  /report - Report generation
/examples - Example notebooks
/tests - Unit tests

Troubleshooting

ImportError: No module named 'datainsight'
- Activate venv and run `pip install -e .` from project root

UnicodeDecodeError on CSV
- Specify encoding: `di.io.read_csv("file.csv", encoding="latin1")`

Plotly charts not showing in Jupyter
- Run `pip install "jupyterlab>=3"`, then restart kernel

SQL connection fails
- Verify SQLAlchemy URI format: `postgresql://user:pass@host/db`

Contributing

1. Fork the repository
2. Create branch: `git checkout -b feature/my-analysis`
3. Run tests: `pytest tests/`
4. Commit and open Pull Request

License

MIT License - see LICENSE file

2) Prompt 2 — Step-by-Step Guide

Feature chosen: Import a CSV, clean missing data, and create an interactive visualization

User level: Beginner

How to Clean Data and Create an Interactive Plot in DataInsight

Prerequisites
- DataInsight installed with venv activated
- Jupyter Notebook installed
- A CSV file with at least two numeric columns (use `examples/sample.csv`)

Process overview: You will load raw data, fill missing values, remove outliers, then build an interactive scatter plot you can zoom and export.

Steps
1. Start Jupyter
  bash
jupyter notebook

Open `examples/01_quickstart.ipynb`

2. Import DataInsight
python
import datainsight as di

3. Load your CSV
python
df = di.io.read_csv("data/experiment.csv")
df.head()

[PLACEHOLDER FOR SCREENSHOT: dataframe head output]

4. Check for missing data
python
di.transform.missing_summary(df)

5. Fill missing values
python
df_clean = di.transform.fill_missing(df, strategy="mean")
Alternative strategies: "median", "drop", "forward_fill"


6. Remove outliers in temperature column
python
df_clean = di.transform.remove_outliers(df_clean, column="temperature", z_thresh=3)

7. Create interactive visualization
python
fig = di.viz.scatter_interactive(
    df_clean, 
    x="time", 
    y="temperature", 
    color="group",
    title="Temperature over Time"
)
fig.show()

8. Export to HTML report
python
di.report.to_html(df_clean, output="my_report.html")

Common mistakes to avoid
- Forgetting to assign the result: `fill_missing` returns a new dataframe, it does not modify in place
- Using wrong column names: Python is case sensitive, "Temperature" is not "temperature"
- Loading Excel without openpyxl: install it first or you get ImportError

Troubleshooting
- Empty plot: check that x and y columns are numeric with `df.dtypes`
- Memory error on large CSV: use `di.io.read_csv("large.csv", chunksize=50000)`
- Plot not interactive: ensure you are using `scatter_interactive` not `scatter_static`, and you are in a notebook not plain terminal


3) Prompt 3 — FAQ Document

DataInsight Frequently Asked Questions

Getting started
Q: What is DataInsight?
A: A Python framework that wraps Pandas, NumPy, Matplotlib, and Plotly into a simple workflow for scientific data analysis.

Q: How do I install it?
A: Clone the repo, create a virtual environment, then `pip install -r requirements.txt`. Requires Python 3.8+.

Q: Do I need Jupyter?
A: Not required, but recommended. All examples are notebooks in /examples.

Common features and functionality
Q: What file types can I import?
A: CSV, Excel (.xlsx), SQL databases via SQLAlchemy, JSON, and REST APIs using `di.io.read_api()`.

Q: How do I clean missing data?
A: Use `di.transform.fill_missing(df, strategy="mean")`. Options are mean, median, mode, forward_fill, or drop.

Q: Can I create interactive charts?
A: Yes. Use functions in `di.viz` like `scatter_interactive`, `line_interactive`, and `heatmap_interactive`. They return Plotly figures.

Q: How do I generate a report?
A: Call `di.report.to_html(df, summary, figures, output="report.html")` or `to_pdf()` if wkhtmltopdf is installed.

Troubleshooting common issues
Q: I get ParserError on CSV import
A: Try specifying separator and encoding: `read_csv("file.csv", sep=";", encoding="utf-8")`

Q: Plots look different on my machine
A: Set a consistent theme: `di.set_config(plotly_theme="plotly_white")`

Q: Tests fail after my changes
A: Run `pytest tests/ -v` to see which module broke. Ensure you did not change function signatures in /datainsight/io

Data import and performance
Q: Can DataInsight handle large datasets?
A: Yes, use chunked reading or Dask integration. For files over 1GB, use `read_csv(chunksize=100000)`.

Q: How do I connect to my university SQL server?
A: Pass SQLAlchemy URI: `di.io.read_sql("SELECT * FROM experiments", "postgresql://user:pass@host:5432/db")`
