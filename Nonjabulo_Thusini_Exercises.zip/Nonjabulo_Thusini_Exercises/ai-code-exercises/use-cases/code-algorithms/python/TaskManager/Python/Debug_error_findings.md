1) Tracing Error Messages and Stack Traces — your three go-to prompts
Prompt A: Error Message Translation (use first, before you change code)

Code
I need help understanding this error from my [Python 3.11 / Node 18 / etc.] [Flask / React / etc.] app.

Error:
[
Traceback (most recent call last):
  File "/home/user/projects/inventory/stock_manager.py", line 25, in <module>
    main()
  File "/home/user/projects/inventory/stock_manager.py", line 17, in main
    print_inventory_report(items)
  File "/home/user/projects/inventory/stock_manager.py", line 10, in print_inventory_report
    for i in range(len(items)):
      print(f"Item {i+1}: {items[i]['name']} - Quantity: {items[i]['quantity']}")
IndexError: list index out of range
]

Context:
- Happened when: [e.g., clicking "Export CSV" in DataInsight]
- App type: [e.g., data analysis script using Pandas]
- Versions: [list]

I'm unfamiliar with [term from error], explain that part extra.

13 lines hidden
Prompt B: Root Cause Analysis (use when you have the code)
Add the snippets from the files named in the trace, 10 lines before and after the error line. Ask for the chain of events, not just the fix.

Prompt C: Dependency and Version Tracing (use for "it worked yesterday")
Include OS, package manager version, and the exact block from requirements.txt or package.json, plus what you changed last.

Why these work: they force you to give AI the five things it needs — full error, your code, what you were doing, environment, and what you already tried. Without those, you get generic guesses.

2) Identifying Performance Bottlenecks — three more prompts
Prompt D: Slow Code Analysis
Give the function, input size (e.g., "DataInsight processing 50k rows"), current runtime, and ask for why it is slow in simple terms plus 2-3 specific improvements. Always ask for the concept to learn, not just the rewrite.

Prompt E: Memory Usage
Include when it crashes ("after 1,000 images"), memory limit, and the loop or cache you suspect. Ask for tools to profile — in Python that is tracemalloc or memory_profiler, in Node it is --inspect.

Prompt F: Slow Database Query
Paste the query, table row counts, existing indexes, and execution time. Ask for both a rewrite and an index suggestion, plus how to measure with EXPLAIN ANALYZE.

Common pitfalls — the checklist from your chapter, simplified
Incomplete error: always paste the whole traceback. AI needs the bottom caused-by line and the top where your file appears.
Missing code: include imports, function definition, and the call site. If the trace mentions three files, paste all three snippets.
No environment: "Python 3.9 on Ubuntu, Pandas 2.1" matters more than you think for version conflicts.
Premature fix focus: ask "what does this mean" before "how do I fix it". You learn the pattern and avoid it next time.
Ignoring patterns: ask "is this a broader anti-pattern in my code" — AI will spot things like catching all exceptions or not closing files.