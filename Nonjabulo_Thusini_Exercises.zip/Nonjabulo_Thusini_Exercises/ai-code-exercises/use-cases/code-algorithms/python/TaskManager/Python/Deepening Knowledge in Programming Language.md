The 3 prompts are your toolkit

1. Prompt: Idiomatic Code → Use when your code “works but feels clunky”
This is Prompt 1 from the last chapter, but focused on language idioms not just names.
Example for your calculate_task_score: An AI would say “Use dict.get(priority, 0) instead of if priority in weights - it’s more Pythonic”.

2. Prompt: Code Quality Improvements → Use for a full review before PR
This combines readability + performance + maintainability. It’s what a senior dev does in code review.
Key difference from Prompt 1: It also rates your code and explains why something is a smell in that language.

3. Prompt: Understanding Language Feature → Use when you hit something new
Example: “I want to improve my understanding of dataclasses in Python” or “reduce() in JavaScript”. AI gives examples + project ideas + pitfalls.

The #1 pitfall for this chapter
Blindly accepting suggestions without understanding
The chapter warns: “Becoming dependent on completion for basic syntax” and “Missing opportunities to learn why”.

Rule: If you can’t explain the AI’s suggestion to a teammate, don’t commit it. Ask the follow-up: “Why is list comprehension better than a for-loop here?”

Let’s apply this to code you already know
You did calculate_task_score in Python. Let’s run the Idiomatic Code prompt on it:

Your version uses if task.due_date: and nested if/elif.

AI idiomatic suggestion would likely be:

Python
from datetime import datetime, timedelta
from enum import Enum

PRIORITY_WEIGHTS = {TaskPriority.LOW: 1, TaskPriority.MEDIUM: 2, TaskPriority.HIGH: 4, TaskPriority.URGENT: 6}
OVERDUE_BOOST, TODAY_BOOST = 35, 20

def calculate_task_score(task) -> int:
    score = PRIORITY_WEIGHTS.get(task.priority, 0) * 10
    
    if days_until := _days_until_due(task.due_date):
        score += 35 if days_until < 0 else 20 if days_until == 0 else 15 if days_until <= 2 else 10 if days_until <= 7 else 0
    
    # ... rest using walrus operator, constants, early returns

8 lines hidden
Why these changes follow Python best practices:

:= walrus operator: avoids calculating days_until_due twice
Constants OVERDUE_BOOST: magic numbers are a code smell in Python
.get(priority, 0): idiomatic dict lookup with default vs if key in dict
Type hint -> int: Python 3.5+ best practice for readability
Language features you weren’t taking advantage of: Enums, walrus operator, f-strings, dataclasses for Task.

How to practice this chapter
Pick one function you wrote: calculate_task_score, process_orders, validateUserData
Run Prompt: Idiomatic Code on it with your language specified
Ask 1 follow-up: “Why is X more idiomatic than Y?”
Document 1 learning: “TIL that Python dict.get() with default is preferred over if key in dict”
