Exercise 2: Function Refactoring (Python)
Different responsibilities in process_orders:

Validation: inventory check, quantity check, customer check
Pricing: base price, discount calc
Shipping calc
Tax calc
Inventory mutation
Revenue tracking
Result building
Error collection
That’s 8 jobs. Rule of thumb: 1 function = 1 job.

How to break it down:

Python
def process_orders(orders, inventory, customer_data):
    results, error_orders, total_revenue = [], [], 0

    for order in orders:
        validation_error = validate_order(order, inventory, customer_data)
        if validation_error:
            error_orders.append(validation_error)
            continue

        order_result = calculate_order_totals(order, inventory, customer_data)
        update_inventory(order, inventory)
        total_revenue += order_result['final_price']
        results.append(order_result)

    return {'processed_orders': results, 'error_orders': error_orders, 'total_revenue': total_revenue}

def validate_order(order, inventory, customer_data):
    # Returns error dict or None. Checks inventory, quantity, customer.

def calculate_order_totals(order, inventory, customer_data):
    # Returns dict with price, shipping, tax, final_price

def update_inventory(order, inventory):
    # Mutates inventory. Single responsibility.

19 lines hidden
Other issues AI should point out:

Mutates inventory parameter directly. Side effects make testing hard.
Magic numbers: 0.9, 5.99, 15.99, 0.08. Should be constants: PREMIUM_DISCOUNT, DOMESTIC_SHIPPING_FEE.
No handling for empty orders list.
price < 50 boundary. What if price is exactly 50?