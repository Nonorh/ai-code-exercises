Exercise : Algorithm Deconstruction Challenge

1. I choose Python

Algorithm 1: Task Priority Sorting
What It Does
It assigns a numeric score to each task based on four factors, then sorts tasks highest-score-first. The top N tasks can be retrieved with get_top_priority_tasks.

Score Calculation Breakdown

Final Score = Base Priority Score
            + Due Date Bonus
            - Completion Penalty
            + Tag Boost
            + Recency Boost

Factor	  Condition	                   Points
Priority   URGENT	                    +60
           HIGH	                    +40
           MEDIUM	                    +20
           LOW	                    +10
Due Date   Overdue	                    +35
           Duetoday                      +20
           Due ≤ 2 days	             +15
           Due ≤ 7 days	             +10
           No due date	              +0
Status	   DONE	                    −50
           REVIEW	                    −15
Tags	"blocker", "critical", "urgent"    +8
Recency	Updated < 1 day ago	       +5


┌──────────────────────────────────────────┐
│           sort_tasks_by_importance()      │
│                                          │
│  For each task → calculate_task_score()  │
│       │                                  │
│       ▼                                  │
│  ┌─────────────────────────────────┐     │
│  │  1. priority_weight × 10        │     │
│  │  2. + due date bonus            │     │
│  │  3. - completion penalty        │     │
│  │  4. + tag boost                 │     │
│  │  5. + recency boost             │     │
│  └─────────────────────────────────┘     │
│       │                                  │
│       ▼                                  │
│  Sort [(score, task), ...] descending    │
│       │                                  │
│       ▼                                  │
│  Return sorted task list                 │
└──────────────────────────────────────────┘
Concrete Example
Imagine two tasks:

Task A: HIGH priority, due tomorrow, tagged "blocker", updated today
Score = 40 + 15 + 8 + 5 = 68
Task B: URGENT priority, DONE status, no due date
Score = 60 + 0 − 50 = 10
Task A ranks higher despite lower base priority — because status and urgency signals outweigh raw priority.

Key Insight
The algorithm deliberately buries completed tasks (−50) so they don't clutter the active view, while surfacing overdue tasks aggressively (+35). This is a design choice that mirrors real-world task management behavior.

Algorithm 2: Task Text Parser
What It Does
It reads a plain-English string like:

"Finish report for client XYZ !urgent #friday #work @project"
…and produces a structured Task object with title, priority, due_date, and tags.

Parsing Rules
Marker	Meaning	Example
Plain text	Task title	"Buy milk"
@word	Add a tag	@shopping
!1 or !low	Low priority	!1
!2 or !medium	Medium priority	!2
!3 or !high	High priority	!high
!4 or !urgent	Urgent priority	!urgent
#tomorrow	Due date = today + 1	#tomorrow
#friday	Due date = next Friday	#friday
#2025-12-31	Explicit date	#2025-12-31
Parsing Pipeline (Visual)
Input: "Buy milk @shopping !2 #tomorrow"
           │
           ▼
┌─────────────────────────────────────┐
│  Step 1: Find !N or !name           │
│  Match: "!2" → priority = MEDIUM    │
│  Remove from title string           │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│  Step 2: Find @tag                  │
│  Match: "@shopping" → tags = [...]  │
│  Remove from title string           │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│  Step 3: Find #date                 │
│  Match: "#tomorrow" → due_date      │
│  Remove from title string           │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│  Step 4: Clean whitespace           │
│  title = "Buy milk"                 │
└──────────────┬──────────────────────┘
               │
               ▼
        Task(title="Buy milk",
             priority=MEDIUM,
             due_date=tomorrow,
             tags=["shopping"])
Regex Patterns Explained
Pattern	Plain English
\s!([1-4]|urgent|high|medium|low)\b	"A space, then !, then a number 1–4 or a priority word, ending at a word boundary"
\s@(\w+)	"A space, then @, then one or more word characters"
\s#(\w+)	"A space, then #, then one or more word characters"
Key Insight
The parser uses destructive extraction — it strips each marker from the title as it finds it, so the final title is clean. The order matters: priority → tags → dates → trim. If the order were reversed, leftover markers could corrupt the title.

Algorithm 3: Task List Merging (Two-Way Sync)
What It Does
It takes two dictionaries of tasks (local and remote), compares them by ID, and produces:

A merged final task dictionary
Lists of what needs to be created or updated on each side
Three Cases
For every unique task_id across both sources:

  ┌─────────────────────────────────────────────────┐
  │  Only in LOCAL?  → Add to remote (to_create_remote) │
  │  Only in REMOTE? → Add to local  (to_create_local)  │
  │  In BOTH?        → resolve_task_conflict()           │
  └─────────────────────────────────────────────────┘
Conflict Resolution Logic
resolve_task_conflict(local, remote):
    │
    ├─ Base: deep copy of local task
    │
    ├─ TITLE / DESC / PRIORITY / DUE DATE:
    │      remote.updated_at > local.updated_at?
    │           YES → use remote values, flag update_local = True
    │           NO  → keep local values, flag update_remote = True
    │
    ├─ STATUS (special rule — "completed wins"):
    │      remote = DONE, local ≠ DONE → use DONE, update_local
    │      local = DONE, remote ≠ DONE → keep DONE, update_remote
    │      both non-DONE but different → most recent wins
    │
    ├─ TAGS (union rule — never lose a tag):
    │      merged_tags = local_tags ∪ remote_tags
    │      if local changed → update_local
    │      if remote changed → update_remote
    │
    └─ TIMESTAMP:
           merged.updated_at = max(local.updated_at, remote.updated_at)
Visual Sync Flow
LOCAL store          REMOTE store
    │                    │
    └──────┬─────────────┘
           │
    merge_task_lists()
           │
    ┌──────┴──────────────────────────────┐
    │  Collect all unique IDs             │
    │  For each ID → classify case        │
    │  Case 3 → resolve_task_conflict()   │
    └──────┬──────────────────────────────┘
           │
    Returns 5 outputs:
    ├── merged_tasks          (full picture)
    ├── to_create_remote      (push new local → remote)
    ├── to_update_remote      (push local wins → remote)
    ├── to_create_local       (pull new remote → local)
    └── to_update_local       (pull remote wins → local)
Key Insight
The "completed wins" rule is a deliberate asymmetry: completion is treated as a one-way ratchet. You can't accidentally un-complete a task via sync. Tags use a union (never delete), which is also asymmetric — you can't remove a tag by editing one side. These are real-world product decisions baked into the algorithm.

Reflection Answers
1. How did breaking down the algorithm change your understanding?
Before analysis, the scoring algorithm looks like a pile of if statements. After breakdown, you see it's actually a multi-criteria decision model — each factor is a weighted signal, and the final score is a composite. Understanding why each weight exists (e.g., why overdue = +35 but due-today = +20) reveals the product intent behind the code.

2. What was still difficult after explanation?
Edge cases in the text parser: What happens if someone writes !urgent !high? The regex finds the first match only — but is that intentional? The code takes priority_matches[0], silently ignoring duplicates.
Timestamp ties in conflict resolution: If local.updated_at == remote.updated_at, the else branch fires, meaning local "wins" by default. This is a subtle, undocumented tie-breaking rule.
3. How would you explain Algorithm 1 to another junior developer?
"Think of it like a school ranking system. Every task gets a score based on how urgent it is, how close the deadline is, whether it's already done, and whether it has VIP tags. We then sort by score, highest first. It's like a leaderboard for your to-do list."

4. Potential Improvements
Algorithm	Improvement Idea
Scoring	Make weights configurable per user/team instead of hardcoded
Scoring	Add a dependency factor: blocked tasks should score lower
Parser	Support #2025-12-31 style dates more robustly with dateutil.parser
Parser	Handle multiple priorities gracefully (warn or pick highest)
Merge	Add a tombstone mechanism so deleted tasks don't reappear after sync
Merge	Log conflict decisions for audit trail / undo support
Merge	"Completed wins" could be made configurable — some teams want local to override
Summary Table
Algorithm	Core Technique	Key Design Decision
Priority Sorting	Weighted multi-factor scoring	Completed tasks heavily penalized (−50)
Text Parser	Regex extraction + destructive removal	Markers stripped from title in order
List Merging	ID-based set union + timestamp arbitration	Completed status is a one-way ratchet; tags use union

---------------------------------------------------
