Exercise : Code Documentation

1. The Original Code I chose to document

# task_manager/storage.py
import json
import os
from datetime import datetime
from models import Task, TaskPriority, TaskStatus

class TaskEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Task):
            task_dict = obj.__dict__.copy()
            task_dict['priority'] = obj.priority.value
            task_dict['status'] = obj.status.value
            # Convert datetime objects to ISO format strings
            for key in ['created_at', 'updated_at', 'due_date', 'completed_at']:
                if task_dict.get(key) is not None:
                    task_dict[key] = task_dict[key].isoformat()
            return task_dict
        return super().default(obj)

class TaskDecoder(json.JSONDecoder):
    def __init__(self, *args, **kwargs):
        json.JSONDecoder.__init__(self, object_hook=self.object_hook, *args, **kwargs)

    def object_hook(self, obj):
        if 'id' in obj and 'title' in obj:
            task = Task(obj['title'], obj.get('description', ''))
            task.id = obj['id']
            task.priority = TaskPriority(obj['priority'])
            task.status = TaskStatus(obj['status'])

            # Convert ISO format strings to datetime objects
            for key in ['created_at', 'updated_at', 'completed_at']:
                if obj.get(key):
                    setattr(task, key, datetime.fromisoformat(obj[key]))

            if obj.get('due_date'):
                task.due_date = datetime.fromisoformat(obj['due_date'])

            task.tags = obj.get('tags', [])
            return task
        return obj

class TaskStorage:
    def __init__(self, storage_path="tasks.json"):
        self.storage_path = storage_path
        self.tasks = {}
        self.load()

    def load(self):
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, 'r') as f:
                    tasks_data = json.load(f, cls=TaskDecoder)
                    if isinstance(tasks_data, list):
                        for task in tasks_data:
                            self.tasks[task.id] = task
            except Exception as e:
                print(f"Error loading tasks: {e}")

    def save(self):
        try:
            with open(self.storage_path, 'w') as f:
                json.dump(list(self.tasks.values()), f, cls=TaskEncoder, indent=2)
        except Exception as e:
            print(f"Error saving tasks: {e}")

    def add_task(self, task):
        self.tasks[task.id] = task
        self.save()
        return task.id

    def get_task(self, task_id):
        return self.tasks.get(task_id)

    def update_task(self, task_id, **kwargs):
        task = self.get_task(task_id)
        if task:
            task.update(**kwargs)
            self.save()
            return True
        return False

    def delete_task(self, task_id):
        if task_id in self.tasks:
            del self.tasks[task_id]
            self.save()
            return True
        return False

    def get_all_tasks(self):
        return list(self.tasks.values())

    def get_tasks_by_status(self, status):
        return [task for task in self.tasks.values() if task.status == status]

    def get_tasks_by_priority(self, priority):
        return [task for task in self.tasks.values() if task.priority == priority]

    def get_overdue_tasks(self):
        return [task for task in self.tasks.values() if task.is_overdue()]

2. The documentation I generated using prompt 1:

The Code at a Glance
storage.py contains four classes that together form the persistence layer of the task manager:

TaskEncoder  ──► converts Task objects → JSON-safe dicts
TaskDecoder  ──► converts JSON dicts → Task objects
TaskStorage  ──► manages in-memory dict + file I/O + CRUD


TaskEncoder
class TaskEncoder(json.JSONEncoder):
    """
    Custom JSON encoder for Task objects.

    Extends the standard JSONEncoder to handle Task model serialization,
    converting enum fields to their raw values and datetime objects to
    ISO 8601 strings so the result is JSON-serializable.

    Usage:
        json.dumps(task_list, cls=TaskEncoder, indent=2)

    Notes:
        - Only Task instances are intercepted; all other types fall
          through to the default JSONEncoder behaviour.
        - datetime fields serialized: created_at, updated_at,
          due_date, completed_at.
        - Enum fields serialized: priority (TaskPriority.value),
          status (TaskStatus.value).
    """

    def default(self, obj):
        """
        Serialize a Task instance to a JSON-compatible dictionary.

        Parameters
        ----------
        obj : any
            The object to serialize. Handled specially when
            isinstance(obj, Task) is True.

        Returns
        -------
        dict
            A flat dictionary with all Task fields, enums replaced
            by their .value strings, and datetimes replaced by
            ISO 8601 strings (e.g. '2026-06-11T09:00:00').

        Raises
        ------
        TypeError
            Raised by the parent class when obj is not a Task and
            has no default serialization path.

        Examples
        --------
        >>> import json
        >>> task = Task("Fix login bug")
        >>> task.priority = TaskPriority.HIGH
        >>> json.dumps(task, cls=TaskEncoder)
        '{"id": "...", "title": "Fix login bug", "priority": "high", ...}'
        """
TaskDecoder
class TaskDecoder(json.JSONDecoder):
    """
    Custom JSON decoder that reconstructs Task objects from raw dicts.

    Uses the object_hook mechanism so every JSON object (dict) in the
    file is passed through object_hook before being returned to the
    caller. Dicts that look like Tasks (contain 'id' and 'title') are
    converted; all other dicts are returned unchanged.

    Usage:
        json.load(file_handle, cls=TaskDecoder)

    Notes:
        - Reconstruction is heuristic: any dict with 'id' + 'title'
          keys is treated as a Task. This could misfire if other
          data structures share those keys.
        - Missing optional fields (description, tags, due_date, etc.)
          are handled with .get() defaults, so partial records load
          without error.
        - datetime strings are parsed with datetime.fromisoformat(),
          which requires Python 3.7+.
    """

    def object_hook(self, obj):
        """
        Convert a raw JSON dict to a Task if it matches the Task schema.

        Parameters
        ----------
        obj : dict
            A raw Python dictionary produced by the JSON parser.

        Returns
        -------
        Task
            A fully reconstructed Task instance when 'id' and 'title'
            are present in obj.
        dict
            The original dict unchanged when it does not match the
            Task schema.

        Raises
        ------
        ValueError
            If priority or status strings do not match a valid enum
            value (e.g. corrupted file).
        ValueError
            If a datetime string is not a valid ISO 8601 format.

        Examples
        --------
        >>> decoder = TaskDecoder()
        >>> result = decoder.decode('{"id":"abc","title":"Buy milk","priority":"medium","status":"todo","created_at":"2026-06-11T08:00:00","updated_at":"2026-06-11T08:00:00","tags":[]}')
        >>> isinstance(result, Task)
        True
        """
TaskStorage
class TaskStorage:
    """
    File-backed CRUD store for Task objects.

    Maintains an in-memory dictionary of tasks keyed by task ID and
    synchronizes it with a JSON file on every write operation. Reads
    are served from memory; the file is only re-read at startup.

    Parameters
    ----------
    storage_path : str, optional
        Path to the JSON persistence file. Defaults to 'tasks.json'
        in the current working directory.

    Attributes
    ----------
    storage_path : str
        Resolved path to the backing JSON file.
    tasks : dict[str, Task]
        In-memory task store keyed by task.id.

    Notes:
        - Write-through strategy: every mutation (add, update, delete)
          immediately rewrites the full JSON file.
        - No file locking: concurrent writes from multiple processes
          will corrupt the file.
        - Load errors are swallowed and printed; the store starts empty
          rather than raising on a bad file.

    Examples
    --------
    >>> store = TaskStorage("my_tasks.json")
    >>> t = Task("Deploy hotfix")
    >>> store.add_task(t)
    >>> store.get_task(t.id).title
    'Deploy hotfix'
    """

    def load(self):
        """
        Load tasks from the JSON file into self.tasks.

        Called automatically by __init__. Safe to call again to
        reload from disk, but will overwrite any unsaved in-memory
        changes.

        Returns
        -------
        None

        Side Effects
        ------------
        Populates self.tasks from file. Prints an error message and
        leaves self.tasks empty if the file is missing, unreadable,
        or malformed.

        Notes
        -----
        Expects the JSON file to contain a top-level array of Task
        objects. A top-level dict or scalar will not populate tasks
        (isinstance list check will fail silently).
        """

    def save(self):
        """
        Persist the current in-memory task store to the JSON file.

        Serializes self.tasks.values() as a JSON array using
        TaskEncoder. Called automatically after every write operation.

        Returns
        -------
        None

        Raises
        ------
        None (exceptions are caught, printed, and swallowed).

        Notes
        -----
        Full rewrite on every call — O(n) cost per mutation.
        For large task lists consider batching or append-only logs.
        """

    def add_task(self, task: Task) -> str:
        """
        Add a new task to the store and persist immediately.

        Parameters
        ----------
        task : Task
            The Task instance to store. task.id must be unique;
            an existing task with the same ID will be silently
            overwritten.

        Returns
        -------
        str
            The task's ID string.
        """

    def get_task(self, task_id: str):
        """
        Retrieve a single task by its ID.

        Parameters
        ----------
        task_id : str
            The unique identifier of the task.

        Returns
        -------
        Task or None
            The Task instance if found; None if the ID does not exist.
        """

    def update_task(self, task_id: str, **kwargs) -> bool:
        """
        Apply keyword-argument updates to an existing task and save.

        Parameters
        ----------
        task_id : str
            ID of the task to update.
        **kwargs
            Field-value pairs forwarded to task.update().
            Valid keys mirror Task attributes (title, priority,
            status, due_date, tags, description, etc.).

        Returns
        -------
        bool
            True if the task was found and updated; False if the
            task_id does not exist in the store.

        Notes
        -----
        Delegates validation and timestamp bumping to task.update().
        """

    def delete_task(self, task_id: str) -> bool:
        """
        Remove a task from the store permanently.

        Parameters
        ----------
        task_id : str
            ID of the task to delete.

        Returns
        -------
        bool
            True if the task existed and was deleted; False if not found.

        Notes
        -----
        Deletion is immediate and irreversible. No soft-delete or
        recycle-bin mechanism exists in the current implementation.
        """

    def get_all_tasks(self) -> list:
        """
        Return all tasks as an unordered list.

        Returns
        -------
        list[Task]
            Snapshot of all tasks at call time. Mutating the returned
            list does not affect self.tasks, but mutating individual
            Task objects inside it does (they are not deep-copied).
        """

    def get_tasks_by_status(self, status: TaskStatus) -> list:
        """
        Filter tasks by status.

        Parameters
        ----------
        status : TaskStatus
            Enum value to filter on (e.g. TaskStatus.TODO).

        Returns
        -------
        list[Task]
            All tasks whose .status matches the given value.
            Returns an empty list if none match.
        """

    def get_tasks_by_priority(self, priority: TaskPriority) -> list:
        """
        Filter tasks by priority level.

        Parameters
        ----------
        priority : TaskPriority
            Enum value to filter on (e.g. TaskPriority.HIGH).

        Returns
        -------
        list[Task]
            All tasks whose .priority matches the given value.
        """

    def get_overdue_tasks(self) -> list:
        """
        Return all tasks whose due date has passed and are not done.

        Returns
        -------
        list[Task]
            Tasks for which task.is_overdue() returns True.
            The definition of 'overdue' is delegated entirely to
            the Task model's is_overdue() method.

        Notes
        -----
        Tasks without a due_date are never overdue by convention
        (assuming is_overdue() returns False when due_date is None).
        """
3. The insights or improvements you identified using Prompt 2

Prompt 2 — Intent & Logic Explanation
What is this module trying to accomplish?
storage.py solves the object ↔ file boundary problem. Python's Task objects live in memory and use rich types (enums, datetimes). JSON files only understand strings, numbers, lists, and dicts. This module bridges that gap in both directions, then wraps everything in a simple CRUD interface.

Step-by-step logic breakdown
WRITE PATH
──────────
Task object
    │
    ▼
TaskEncoder.default()
    ├─ copy __dict__
    ├─ replace priority enum → .value string
    ├─ replace status enum  → .value string
    └─ replace each datetime → .isoformat() string
    │
    ▼
json.dumps() → JSON string → file on disk


READ PATH
─────────
File on disk → json.load()
    │
    ▼  (called for EVERY dict in the JSON tree)
TaskDecoder.object_hook()
    ├─ if 'id' + 'title' present:
    │       Task(title, description)
    │       task.id = obj['id']
    │       priority = TaskPriority(string)   ← enum reconstruction
    │       status   = TaskStatus(string)     ← enum reconstruction
    │       datetimes = fromisoformat(string) ← datetime reconstruction
    │       tags = obj.get('tags', [])
    │       return Task
    └─ else: return obj unchanged
    │
    ▼
tasks_data (list of Task objects)
    │
    ▼
TaskStorage.tasks dict  {id: Task, id: Task, ...}
Key design assumptions and edge cases

#	Assumption / Edge Case	Impact
1	object_hook fires on every nested dict	A nested dict with id+title keys (e.g. inside a description) would be wrongly reconstructed as a Task
2	load() expects a top-level JSON array	If the file was manually edited to a dict, tasks silently stay empty
3	save() does a full rewrite every time	1,000 tasks = 1,000-task file rewritten on every single add/update/delete
4	add_task() silently overwrites on duplicate ID	No uniqueness guard — a re-added task replaces the old one without warning
5	load() and save() swallow exceptions	A corrupted file prints an error but the app keeps running with zero tasks
6	Returned lists are shallow copies	Callers mutating Task objects inside the list affect the live store
7	No file locking	Two processes writing simultaneously will corrupt the JSON file
Visual Architecture Diagram
┌─────────────────────────────────────────────────────────┐
│                     TaskStorage                         │
│                                                         │
│  self.tasks = { "abc123": , "def456":  }   │
│                                                         │
│  ┌─────────────┐   add / update / delete   ┌─────────┐ │
│  │  Caller /   │ ─────────────────────────►│  CRUD   │ │
│  │  App Layer  │ ◄─────────────────────────│ Methods │ │
│  └─────────────┘   Task or bool/str        └────┬────┘ │
│                                                 │      │
│                                          self.save()   │
│                                                 │      │
└─────────────────────────────────────────────────┼──────┘
                                                  │
                    ┌─────────────────────────────┘
                    ▼
         ┌──────────────────┐
         │   TaskEncoder    │  Task → dict (enums+datetimes flattened)
         └────────┬─────────┘
                  │ json.dumps()
                  ▼
         ┌──────────────────┐
         │   tasks.json     │  [ {id, title, priority, ...}, ... ]
         └────────┬─────────┘
                  │ json.load()  (on startup)
                  ▼
         ┌──────────────────┐
         │   TaskDecoder    │  dict → Task (enums+datetimes restored)
         └──────────────────┘
4. A Final Combined Documentation version:
 
Combined Final Documentation — Key Inline Comments
class TaskStorage:
    def __init__(self, storage_path="tasks.json"):
        self.storage_path = storage_path
        self.tasks = {}   # Primary in-memory store: {task_id: Task}
        self.load()       # Hydrate from disk immediately on construction

    def load(self):
        # Guard: only attempt to read if the file actually exists
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, 'r') as f:
                    # TaskDecoder.object_hook fires on every nested dict
                    tasks_data = json.load(f, cls=TaskDecoder)
                    # Defensive check: file must contain a top-level list
                    if isinstance(tasks_data, list):
                        for task in tasks_data:
                            # Index by ID for O(1) lookups
                            self.tasks[task.id] = task
            except Exception as e:
                # Fail-safe: log the error but don't crash the app.
                #  Risk: silent data loss if file is corrupted.
                print(f"Error loading tasks: {e}")

    def save(self):
        try:
            with open(self.storage_path, 'w') as f:
                # Full rewrite every time — simple but O(n) per mutation.
                # TaskEncoder handles Task → JSON-safe dict conversion.
                json.dump(list(self.tasks.values()), f,
                          cls=TaskEncoder, indent=2)
        except Exception as e:
            #  Silent failure: caller receives no signal that save failed.
            print(f"Error saving tasks: {e}")

    def update_task(self, task_id, **kwargs):
        task = self.get_task(task_id)
        if task:
            # Delegate field validation and updated_at bump to Task.update()
            task.update(**kwargs)
            self.save()
            return True
        return False   # Caller must check return value to detect missing ID
3. Improvement Opportunities:
#	Location	Current Behaviour	Suggested Improvement
1	save()	Full file rewrite on every mutation	Add a dirty-flag or batch writes with a debounce timer
2	load() / save()	Exceptions silently swallowed	Raise a custom StorageError so callers can react
3	object_hook	Any dict with id+title treated as Task	Add a "_type": "Task" sentinel field during encoding
4	add_task()	Duplicate ID silently overwrites	Raise ValueError or return False on collision
5	get_all_tasks()	Returns shallow-copy list with live Task refs	Return copy.deepcopy(list(...)) to prevent accidental mutation
6	File access	No file locking	Use fcntl.flock (Unix) or msvcrt.locking (Windows)
7	load()	Expects top-level list; dict silently ignored	Validate schema version and raise on unexpected root type
Reflection Questions
1. How did documenting this code change your understanding? Writing the docstrings forced a close read of the object_hook mechanism — it fires on every nested dict, not just top-level ones. That's a subtle bug surface that isn't obvious from a quick skim.

2. What was still difficult after the exercise? The interaction between TaskDecoder.__init__ calling json.JSONDecoder.__init__ with object_hook=self.object_hook is a Python metaclass/MRO pattern that requires knowing how json.JSONDecoder internals work to fully trust.

3. How would you explain this to a junior developer?

"Think of TaskEncoder as a translator that converts your Python objects into plain text before saving to a file, and TaskDecoder as the reverse translator that rebuilds those objects when you load the file back. TaskStorage is the librarian that uses both translators and keeps everything organized in a dictionary in memory."

4. Did you test your understanding against the AI? Key tests to run mentally:

What happens if tasks.json contains {} instead of []? → tasks stays empty, no error raised.
What happens if you add the same task twice? → Second call silently overwrites the first.
What if due_date is null in JSON? → obj.get('due_date') returns None, the if block is skipped, task.due_date stays None. Safe.
5. How would you improve this algorithm? The single highest-impact improvement is replacing the full-rewrite-on-every-mutation pattern with a write-behind cache — accumulate changes in memory and flush to disk either on a timer or when the app closes. This reduces disk I/O from O(n) per operation to O(1) amortized, which matters once the task list grows beyond a few hundred items.


 