Part 1: Framework Comparison
Task: Personal "translation table"

Flask/Django Concept

FastAPI Equivalent

Fundamental Difference

Flask Blueprint

APIRouter

Blueprints group routes. APIRouter does the same but supports dependencies per-router and generates separate OpenAPI tags.

Django Middleware

Middleware + Depends()

Django middleware runs for every request in a fixed order. FastAPI Depends() runs only on endpoints that need it. Use middleware only for CORS, logging, etc.

Flask @app.route

Path Operation @app.get/post

Similar syntax, but FastAPI uses function type hints to auto-parse, validate, and document path/query/body params.

Django Forms / Flask-WTF

Pydantic BaseModel

Django/Flask validate inside the view after data arrives. Pydantic validates before your function runs and auto-converts types.

Django ORM Models

Pydantic + SQLAlchemy/SQLModel

FastAPI has no ORM. Pydantic = API data contract. DB models are separate. Clearer separation of concerns.

Flask g / Django request.user

Depends(get_current_user)

Flask/Django use global/thread-local state. FastAPI injects dependencies explicitly per function. Easier to test, no hidden globals.

Part 2: Understanding Design Choices
Goal: Short summary of FastAPI’s design philosophy

Answer:
FastAPI was designed as "API-first" and "developer experience first".

Why Pydantic: Instead of building a new validation system, FastAPI leverages Pydantic because it uses standard Python type hints. This means validation rules live in your function signature, not in separate schema files. One source of truth.
Why auto API docs: In Flask/Django, docs are written separately and go stale. FastAPI generates OpenAPI/Swagger from your type hints + Pydantic models. Docs are always correct because they’re compiled from code.
Why type hints everywhere: Type hints give 3 things for free: editor autocomplete, runtime validation via Pydantic, and API docs. They make the code self-documenting and catch bugs before runtime.
Why async-first: Flask/Django were designed before async/await was mature in Python. FastAPI is built on Starlette ASGI. You can await database/HTTP calls without blocking. One worker handles thousands of concurrent requests vs Flask needing threads or gevent.
How this influences structure: You structure apps around "path operations + dependencies + Pydantic models" instead of "views + middleware + forms". Validation and serialization are declarative via types, not imperative in view logic.

Part 3: Applied Contextual Learning
Implementation Challenge: JWT Authentication

You can use the code provided. To run it:

Bash
pip install fastapi uvicorn python-jose[cryptography] passlib[bcrypt]
uvicorn main:app --reload
Login: POST /token with form data username=johndoe&password=secret
Use: Add header Authorization: Bearer <token> to access /users/me/

Reflection Question Answers:

How does FastAPI’s approach to authentication compare to frameworks you’ve used before?
In Flask/Django, auth is often done with @login_required decorators or middleware that sets request.user. The user is stored in session/cookies. In FastAPI, auth is a dependency Depends(get_current_user) that decodes a stateless JWT on each request. No server-side sessions by default. The dependency either returns a User object or raises HTTPException(401) before your endpoint code runs.
What advantages does FastAPI’s dependency injection system provide for authentication?
Reusability: Write get_current_user once, use Depends() on any protected route.
Testability: Override dependencies in tests: app.dependency_overrides[get_current_user] = lambda: test_user. No need to mock sessions.
Granularity: Only runs for endpoints that need auth. Django middleware runs for every request even if unneeded.
Explicit: current_user: User = Depends(...) makes it clear the endpoint requires auth and what type you get.
How does type hinting make security implementation clearer compared to other frameworks?
current_user: User = Depends(get_current_active_user) guarantees 3 things at the type level: the endpoint is protected, invalid tokens are rejected automatically, and current_user is a validated User model not None. In Flask you’d write if not g.user: abort(401) manually and IDEs can’t help you. Type hints make security requirements part of the function contract.
What patterns from other frameworks can you identify in the JWT implementation?
OAuth2PasswordBearer = standard OAuth2 flow, same as Django REST Framework.
passlib.CryptContext = same password hashing library Django uses.
HTTPException = similar to Flask abort() or Django Http404/PermissionDenied.
Decorator routing @app.post("/token") = Flask-style, but powered by type hints.
Part 4: Mental Model Translation Exercise
Task: Conceptual diagram/table mapping existing mental model to FastAPI

If your mental model is Django: Request → Middleware → URL routing → View → Model → Template/Serializer → Response

FastAPI mental model: Request → Middleware → Path Operation + Dependencies → Pydantic Model → Response

Django Component

FastAPI Equivalent

Difference in Philosophy

Middleware

Middleware + Depends()

Django: global pipeline. FastAPI: prefer Depends() for per-route logic. Use middleware only for app-wide concerns.

Views

Path Operation Functions

Django views take request, do manual parsing. FastAPI functions take typed params. Framework handles parsing/validation.

URLs.py

APIRouter + decorators

Django: centralized routing. FastAPI: distributed, colocated with logic like Flask Blueprints.

Forms / Serializers

Pydantic BaseModel

Django: validate after instantiating form. Pydantic: validate before function is called. Also generates schema.

ORM Models

SQLModel/SQLAlchemy + Pydantic

Django couples DB + API representation. FastAPI separates them. Pydantic for API, ORM for DB.

Templates

Return dict/Pydantic/HTMLResponse

FastAPI is API-first. Templates exist via Jinja2Templates but aren’t the default.

Updated mental model to incorporate FastAPI’s unique aspects:
Think of FastAPI as "types all the way down". The request hits your function only after Pydantic has converted and validated all inputs based on type hints. Your function returns Python objects. Pydantic serializes them to JSON. OpenAPI docs are generated from the same type hints. Dependencies let you compose behavior like auth, DB sessions, and permissions without inheritance or middleware.