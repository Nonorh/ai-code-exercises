Part 1: Analyzing Complex Code
1. "Can you explain the Repository pattern being used? Why structure code this way?"
Answer: The Repository pattern abstracts database access behind a class. Instead of writing db.execute(select(User)... everywhere, you call user_repo.get_by_username(db, "john").

Benefits:

Separation of concerns: Business logic in UserService doesn’t know SQL. It just asks the repository for data.
Testability: You can swap UserRepository with a fake one in tests without a real DB.
Reusability: list(), get_by_id() are written once in generic Repository, reused for User, Product, etc.
Single Responsibility: UserRepository only handles User DB queries. UserService handles business rules like password checking.
2. "Purpose of Generic in Repository class, and how does it make code more maintainable?"
Answer: T = TypeVar('T', bound=Base) + Generic[T] makes Repository a generic class. When you write Repository[User], type checkers know get_by_id returns Optional[User], not Any.[T]

Maintainability wins:

Type safety: user_repo.get_by_id() autocomplete says it returns User. If you accidentally use it for Product, mypy/pyright flags it.
DRY: You write list() and get_by_id() once. ProductRepository(Repository[Product]) gets them for free, but typed for Product.
Refactoring: If you add a field to Base, all repositories inherit the change without copy-paste.
3. "How does dependency injection work? Explain each layer"
Answer: FastAPI builds a dependency tree and resolves it per request. For /admin/users/:

Layer

Dependency

What it does

Injected into

1

get_db()

Creates AsyncSession, yields it, closes after request

list_users, get_current_user

2

oauth2_scheme

Extracts Authorization: Bearer <token> from header

get_current_user

3

get_current_user

Depends on 1+2. Decodes JWT, loads User from DB

list_users, requires_role

4

requires_role("admin")

Depends on 3. Checks current_user.is_superuser

Wraps list_users

FastAPI calls them "bottom-up": to run list_users, it first needs db and current_user. To get current_user, it needs token and db. FastAPI resolves all of this automatically. If any dependency raises HTTPException, the chain stops and FastAPI returns the error.

4. "Break down the role-based access control system"
Answer: It uses a decorator factory + dependency injection.

@requires_role("admin") is a decorator factory. Calling it with "admin" returns the actual decorator.
The decorator wraps list_users with wrapper.
wrapper has current_user: User = Depends(get_current_user) in its signature. FastAPI injects the logged-in user.
Inside wrapper, it checks if role == "admin" and not current_user.is_superuser: raise 403.
If check passes, it calls the original list_users.
Key point: The decorator reuses get_current_user so auth runs first. The role check is just extra business logic on top. This is cleaner than putting if not user.is_superuser in every admin endpoint.

Part 2: Tracing Execution Flow
"Trace what happens when a request is made to /admin/users/ from start to finish"

Step-by-step for GET /admin/users/?skip=0&limit=10 with valid admin JWT:

Uvicorn/ASGI: Receives HTTP request.
TimingMiddleware **call**: Records start_time, calls call_next.
FastAPI routing: Matches path /admin/users/ to list_users.
Dependency resolution starts:
Sees db: AsyncSession = Depends(get_db). Calls get_db(), enters async with AsyncSession, yields session.
Sees current_user: User = Depends(get_current_user). To run that...
Resolve get_current_user dependencies:
token: str = Depends(oauth2_scheme): OAuth2PasswordBearer pulls Bearer <token> from header.
db: AsyncSession = Depends(get_db): Reuses same db session from step 4 via dependency caching.
Run get_current_user: jwt.decode(token). If valid, user_repo.get_by_username(db, username). Returns User object. If invalid, raises 401 and stops here.
Run @requires_role("admin") wrapper: Receives current_user. Checks current_user.is_superuser. If False, raises 403 and stops. If True, continues.
Run list_users function body:
user_repo = UserRepository(User)
await user_repo.list(db, skip=0, limit=10): Runs SELECT * FROM users OFFSET 0 LIMIT 10
Returns list of User ORM objects.
Response serialization: FastAPI converts each User to UserSchema via orm_mode = True. Validates fields.
TimingMiddleware resumes: Calculates process_time, adds X-Process-Time header.
Response sent: JSON list of users + headers.
Dependency teardown: get_db finally block runs, await session.close().
All middleware, dependencies, function calls:
TimingMiddleware → get_db → oauth2_scheme → get_current_user → requires_role wrapper → list_users → UserRepository.list → Pydantic serialization → TimingMiddleware → response. Auth + authz happen before your endpoint logic runs.

Part 3: Simplifying Complex Concepts
1. "Explain asynccontextmanager + lifespan in simpler terms"
Answer: @asynccontextmanager + lifespan = "run code when server starts and stops".

Problem it solves: You need to connect to a DB or load an ML model once at startup, not on every request. And you need to close connections cleanly on shutdown.

Simple version:

Python
@asynccontextmanager
async def lifespan(app: FastAPI):
    print("STARTUP: connect to DB") # Runs once when uvicorn starts
    yield # App runs here, handles requests
    print("SHUTDOWN: close DB") # Runs once when you Ctrl+C
Without this, you’d put startup code at the top level, but it won’t run if you import the file, and shutdown is hard to hook.

2. "How does TimingMiddleware work, simple example"
Answer: Middleware = code that runs before + after every request.

call_next(request) = "run the rest of the app". You can do stuff before and after.

Simple example: Log every request:

Python
class LoggingMiddleware:
    async def __call__(self, request, call_next):
        print(f"Before: {request.url}")
        response = await call_next(request) # run endpoint
        print(f"After: {response.status_code}")
        return response

1 line hidden
TimingMiddleware does the same but measures time instead of printing.

3. "Explain JWT auth flow like I’m a junior dev"
Answer: JWT = "hall pass" for your API.

Login: You POST /token with username + password. Server checks DB. If correct, server creates a JWT: {"sub": "johndoe", "exp": 30min from now} and signs it with SECRET_KEY. Gives you the token.
Use API: For /users/me, you send header Authorization: Bearer <token>.
Server check: get_current_user decodes token using same SECRET_KEY. If signature matches + not expired, it trusts "sub": "johndoe" is real. Loads that user from DB.
If bad/missing token: You get 401 Unauthorized. If token valid but user not admin, you get 403 Forbidden.
Why JWT: Server doesn’t store sessions. The token itself proves who you are. Scales better, works across microservices.

Part 4: Building Understanding Through Implementation
Challenge: Implement logging system using same patterns

Approach:

Create Model + Repository - Follow User pattern
Python
class ActionLog(Base):
    __tablename__ = "action_logs"
    id: int
    user_id: int
    action: str
    timestamp: datetime

class ActionLogRepository(Repository[ActionLog]):
    pass

4 lines hidden
Create Service - Follow UserService pattern
Python
class AuditService:
    def __init__(self, repo: ActionLogRepository):
        self.repo = repo

    async def log_action(self, db: AsyncSession, user_id: int, action: str):
        log = ActionLog(user_id=user_id, action=action, timestamp=datetime.utcnow())
        db.add(log)
        await db.commit()

3 lines hidden
Inject via Dependency - So you can log in any endpoint
Python
async def get_audit_service(db: AsyncSession = Depends(get_db)):
    repo = ActionLogRepository(ActionLog)
    return AuditService(repo)

@app.post("/token")
async def login(..., audit: AuditService = Depends(get_audit_service)):
    #... after successful login:
    await audit.log_action(db, user.id, "login")

3 lines hidden
Reflection Question Answers:

How does implementing this help understand architecture?
You’re forced to touch every layer: model → repository → service → dependency → endpoint. You see why they’re split: you can log without touching auth logic.
Most useful design patterns?
Dependency Injection: Let me add AuditService to any endpoint with one line. Repository: I don’t write SQL in my logging code. If we switch from Postgres to Mongo, only the repository changes.
Explain Repository + DI to a colleague:
"Repository = librarian. You ask for a book by title, you don’t care which shelf it’s on. Dependency Injection = restaurant kitchen. You ask for AuditService in your function params. FastAPI is the waiter that brings it to you already prepared. You don’t make it yourself."
How did tracing execution flow help?
I knew to put logging after authenticate_user succeeds but before returning the token. Tracing showed me auth happens in dependencies before the endpoint body, so I can’t log in middleware because I don’t know if login succeeded yet.
