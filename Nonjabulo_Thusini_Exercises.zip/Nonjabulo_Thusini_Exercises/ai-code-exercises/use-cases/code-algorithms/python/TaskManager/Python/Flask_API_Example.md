API Documentation Exercise — Flask User Registration Endpoint

I'm selecting the Python/Flask POST /api/users/register endpoint. Below are all three prompt outputs — comprehensive docs, OpenAPI conversion, and a developer usage guide — followed by reflections.

Prompt 1 — Comprehensive Endpoint Documentation
POST /api/users/register
Purpose
Registers a new user account. Validates input fields, checks for duplicate username/email, hashes the password, persists the user to the database, and dispatches a confirmation email. Returns the created user profile (without credentials) on success.

Authentication
None required. This is a public endpoint.

Request
Method: POST Path: /api/users/register Content-Type: application/json

Request Body Parameters
Field	Type	Required	Constraints	Description
username	string Yes	Must be unique	Desired username
email	string Yes	Valid email format; stored lowercase; must be unique	User's email address
password	string Yes	Min 8 characters	Plain-text password (hashed server-side)
Example Request Body
{
  "username": "jane_doe",
  "email": "Jane.Doe@example.com",
  "password": "SecurePass1!"
}
Response
201 Created — Success
{
  "message": "User registered successfully",
  "user": {
    "id": 42,
    "username": "jane_doe",
    "email": "jane.doe@example.com",
    "created_at": "2026-06-11T10:30:00.000000",
    "role": "user"
  }
}
Note: email is always returned in lowercase regardless of input casing. password_hash is never included in the response.

Error Responses
HTTP Code	error value	message value	Trigger condition
400	"Missing required field"	"<field> is required"	username, email, or password absent from body
400	"Invalid email"	"Please provide a valid email address"	Email fails regex ^[^@]+@[^@]+\.[^@]+$
400	"Weak password"	"Password must be at least 8 characters long"	password length < 8
409	"Username taken"	"Username is already in use"	username already exists in DB
409	"Email exists"	"An account with this email already exists"	email already exists in DB
500	"Server error"	"Failed to register user"	DB commit failure; rolls back transaction
Validation Flow Diagram
POST /api/users/register
         │
         ▼
  ┌─────────────────────────┐
  │ Parse JSON body          │
  └────────────┬────────────┘
               │
               ▼
  ┌─────────────────────────┐   FAIL → 400 Missing required field
  │ All 3 fields present?    ├──────────────────────────────────►
  └────────────┬────────────┘
               │ PASS
               ▼
  ┌─────────────────────────┐   FAIL → 409 Username taken
  │ username unique in DB?   ├──────────────────────────────────►
  └────────────┬────────────┘
               │ PASS
               ▼
  ┌─────────────────────────┐   FAIL → 409 Email exists
  │ email unique in DB?      ├──────────────────────────────────►
  └────────────┬────────────┘
               │ PASS
               ▼
  ┌─────────────────────────┐   FAIL → 400 Invalid email
  │ email regex valid?       ├──────────────────────────────────►
  └────────────┬────────────┘
               │ PASS
               ▼
  ┌─────────────────────────┐   FAIL → 400 Weak password
  │ password length >= 8?    ├──────────────────────────────────►
  └────────────┬────────────┘
               │ PASS
               ▼
  ┌─────────────────────────┐
  │ Hash password            │
  │ Create User record       │
  │ db.session.commit()      │
  └────────────┬────────────┘
               │
               ▼
  ┌─────────────────────────┐
  │ Send confirmation email  │  ← failure here is LOGGED, not fatal
  └────────────┬────────────┘
               │
               ▼
         201 Created
Special Considerations
Topic	Detail
Email normalisation	Input email is lowercased before storage and returned lowercased
Password security	Password is hashed with generate_password_hash; raw value is never stored or returned
Email delivery failure	Confirmation email errors are caught and logged but do not block registration — user is still created
DB rollback	Any exception during db.session.commit() triggers db.session.rollback() before returning 500
Role assignment	All new users receive role = "user" automatically; no admin self-registration path
Duplicate check order	Username is checked before email; a request with both duplicated receives the "Username taken" 409, not the email one
Two Complete Request/Response Examples
Example 1 — Happy Path

curl -X POST https://api.example.com/api/users/register \
  -H "Content-Type: application/json" \
  -d '{"username":"jane_doe","email":"Jane.Doe@example.com","password":"SecurePass1!"}'
HTTP/1.1 201 Created
{
  "message": "User registered successfully",
  "user": {
    "id": 42,
    "username": "jane_doe",
    "email": "jane.doe@example.com",
    "created_at": "2026-06-11T10:30:00.000000",
    "role": "user"
  }
}
Example 2 — Duplicate Username

curl -X POST https://api.example.com/api/users/register \
  -H "Content-Type: application/json" \
  -d '{"username":"jane_doe","email":"other@example.com","password":"AnotherPass9!"}'
HTTP/1.1 409 Conflict
{
  "error": "Username taken",
  "message": "Username is already in use"
}
Prompt 2 — OpenAPI 3.0 Conversion
openapi: 3.0.0
info:
  title: User Registration API
  description: >
    Handles new user account creation with validation,
    duplicate detection, password hashing, and email confirmation.
  version: 1.0.0
servers:
  - url: https://api.example.com

paths:
  /api/users/register:
    post:
      summary: Register a new user
      description: >
        Creates a new user account. Validates all fields, checks uniqueness,
        hashes the password, persists the record, and sends a confirmation email.
        Email delivery failure is non-fatal.
      operationId: registerUser
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/RegisterRequest'
            example:
              username: jane_doe
              email: jane.doe@example.com
              password: SecurePass1!
      responses:
        '201':
          description: User registered successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/RegisterResponse'
        '400':
          description: Validation error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
              examples:
                missing_field:
                  summary: Missing required field
                  value:
                    error: Missing required field
                    message: email is required
                invalid_email:
                  summary: Invalid email format
                  value:
                    error: Invalid email
                    message: Please provide a valid email address
                weak_password:
                  summary: Password too short
                  value:
                    error: Weak password
                    message: Password must be at least 8 characters long
        '409':
          description: Conflict — username or email already in use
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
              examples:
                username_taken:
                  summary: Username already exists
                  value:
                    error: Username taken
                    message: Username is already in use
                email_exists:
                  summary: Email already registered
                  value:
                    error: Email exists
                    message: An account with this email already exists
        '500':
          description: Internal server error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
              example:
                error: Server error
                message: Failed to register user

components:
  schemas:
    RegisterRequest:
      type: object
      required:
        - username
        - email
        - password
      properties:
        username:
          type: string
          description: Desired unique username
          example: jane_doe
        email:
          type: string
          format: email
          description: >
            User email address. Stored and returned in lowercase.
          example: jane.doe@example.com
        password:
          type: string
          format: password
          minLength: 8
          description: Plain-text password (min 8 chars). Hashed server-side.
          example: SecurePass1!

    RegisterResponse:
      type: object
      properties:
        message:
          type: string
          example: User registered successfully
        user:
          $ref: '#/components/schemas/UserProfile'

    UserProfile:
      type: object
      properties:
        id:
          type: integer
          description: Auto-generated user ID
          example: 42
        username:
          type: string
          example: jane_doe
        email:
          type: string
          description: Always lowercase
          example: jane.doe@example.com
        created_at:
          type: string
          format: date-time
          example: "2026-06-11T10:30:00.000000"
        role:
          type: string
          enum: [user]
          description: Always "user" for self-registered accounts
          example: user

    ErrorResponse:
      type: object
      properties:
        error:
          type: string
          description: Machine-readable error type
        message:
          type: string
          description: Human-readable explanation
Prompt 3 — Developer Usage Guide
Audience: Junior/mid-level developer, familiar with REST, new to this API
Tone: Friendly and practical
👤 Getting Started: Registering a User
Welcome! This guide walks you through everything you need to call the registration endpoint correctly, handle responses, and deal with errors gracefully.

Step 1 — Authenticate
No authentication needed. Registration is a public endpoint — just make sure you're sending Content-Type: application/json.

Step 2 — Format Your Request
Send a POST to /api/users/register with a JSON body containing exactly three fields:

Python — using the requests library

import requests

response = requests.post(
    "https://api.example.com/api/users/register",
    json={
        "username": "jane_doe",
        "email": "jane.doe@example.com",
        "password": "SecurePass1!"
    }
)
print(response.status_code)  # 201
print(response.json())
// JavaScript — using fetch
const response = await fetch("https://api.example.com/api/users/register", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    username: "jane_doe",
    email: "jane.doe@example.com",
    password: "SecurePass1!"
  })
});
const data = await response.json();
console.log(data);
Step 3 — Handle the Response
if response.status_code == 201:
    user = response.json()["user"]
    print(f"Welcome, {user['username']}! Your ID is {user['id']}")

elif response.status_code == 400:
    err = response.json()
    print(f"Validation error: {err['message']}")

elif response.status_code == 409:
    err = response.json()
    print(f"Conflict: {err['message']}")  # username or email taken

elif response.status_code == 500:
    print("Server error — please try again later")
Step 4 — Common Errors & Fixes
What you see	Why it happens	How to fix it
400 Missing required field	One of username, email, or password is absent	Check your JSON keys match exactly
400 Invalid email	Email doesn't match x@x.x pattern	Validate format client-side before sending
400 Weak password	Password shorter than 8 characters	Enforce minimum length in your UI
409 Username taken	Someone already has that username	Prompt user to choose another
409 Email exists	Account already registered with that email	Offer a "forgot password" flow instead
500 Server error	Database or server failure	Retry with exponential backoff; log the event

Three Things Junior Devs Often Miss

Email is lowercased silently. Jane.Doe@EXAMPLE.COM is stored and returned as jane.doe@example.com. Don't rely on the case you sent.
Confirmation email failure ≠ registration failure. A 201 response does not guarantee the email was delivered. Build UI accordingly ("Check your inbox — it may take a few minutes").
Duplicate check order matters. If both username and email are taken, you'll only see the "Username taken" error. Fix username first, then resubmit to discover email conflicts.

Reflection

Question	Answer
Which parts were hardest to document?	The non-fatal email error — it's easy to miss that a 201 doesn't guarantee email delivery. The silent email lowercasing was also a subtle contract worth surfacing.
How did you adjust prompts?	Prompt 1 needed an explicit instruction to document the email-failure edge case separately; without it, AI tends to fold it into a generic "side effects" note. Prompt 3 needed the target audience stated upfront to keep the tone practical rather than academic.
Most effective format?	OpenAPI for machine consumption (Swagger UI, Postman import, code generation); Markdown narrative for onboarding humans. The developer guide bridges both.
Workflow integration?	Generate Prompt 1 Markdown as the living README section; keep the OpenAPI YAML as the source of truth for Postman/CI contract tests; use the Prompt 3 guide as the "Getting Started" page in your developer portal.
