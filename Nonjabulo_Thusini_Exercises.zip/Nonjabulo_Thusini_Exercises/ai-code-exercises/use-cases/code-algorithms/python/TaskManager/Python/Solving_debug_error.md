Exercise: Error Diagnosis Challenge

Error Analysis: IndexError – Off by One (Python)
Error Description:
In plain language, Python is saying "you asked for item number 4 in a list that only has 3 items." The traceback is useful because it shows the chain:

main() called print_inventory_report(items)
the crash happened at line 10 inside that function, on items[i]['name']
IndexError: list index out of range means the index i does not exist in items
The most relevant line is not the framework code (there is none here), it is line 10 in stock_manager.py. The other lines just tell you how you got there.

Root Cause:
The loop is written as:

Python
for i in range(len(items) + 1):
items has 3 dictionaries, so len(items) is 3
range(3 + 1) produces 0, 1, 2, 3
Python lists are zero-indexed, so valid indexes are 0, 1, 2 only
On the fourth iteration, i is 3, and items[3] does not exist, so Python raises IndexError
This is a classic off-by-one error. The + 1 was likely added to make the printed "Item 1, Item 2..." look nice, but it was added in the wrong place.

Suggested Solution:
Remove the + 1 from the range, and handle the human-friendly numbering separately.

Fix 1 – minimal change:

Python
def print_inventory_report(items):
    print("===== INVENTORY REPORT =====")
    for i in range(len(items)): # removed + 1
        print(f"Item {i+1}: {items[i]['name']} - Quantity: {items[i]['quantity']}")
    print("============================")
Fix 2 – more Pythonic and safer (prevents this class of bug):

Python
def print_inventory_report(items):
    print("===== INVENTORY REPORT =====")
    for idx, item in enumerate(items, start=1):
        print(f"Item {idx}: {item['name']} - Quantity: {item['quantity']}")
    print("============================")
Tests to verify:

run with 3 items (current case) – should print 3 lines
run with 0 items – should print only header and footer, no crash
run with 1 item – should print "Item 1"
Learning Points:

range(n) stops at n-1. Adding +1 to match human counting breaks the index.
Prefer iterating directly over items or using enumerate() instead of manual indexes – you cannot go out of bounds that way.
This pattern shows up everywhere: loops, slices, pagination. Always test edge cases: empty list, single item, and full list.
If you must use indexes, validate first: if i < len(items):
Reflection Questions
How did the AI’s explanation compare to documentation you found online?
Python docs define IndexError as "sequence index out of range" but do not point to your + 1. An AI analysis using Prompt 1 translated the traceback to your specific file and line, then explained why range(len+1) creates an extra iteration. Online docs give the generic rule, AI gave the contextual cause.

What aspects of the error would have been difficult to diagnose manually?
For a junior developer, the stack trace mixes three function calls and the error points to the print line, not the loop definition two lines above. It is easy to assume the data is wrong instead of the loop bound. Manually you might add print statements for hours. AI immediately isolated line 10 as the symptom and line 9 range(len(items) + 1) as the cause.

How would you modify your code to provide better error messages in the future?

Use enumerate instead of manual indexes
Add a guard: if not items: print("No inventory"); return
In larger apps, log the index and length before access: logger.debug(f"accessing {i} of {len(items)}")
Write a unit test that calls print_inventory_report([]) – it would have caught this instantly
Did the AI help you understand not just the fix, but the underlying concepts?
Yes. Using Prompt 2's root-cause approach, it explained zero-indexing, how range is exclusive on the upper bound, and why off-by-one errors are a pattern not a one-off typo. That transfers to JavaScript loops, Java arrays, and SQL LIMIT clauses, not just this Python script.

