Exercise Part 1: Understanding Project Structure
1. Initial understanding - before AI
Write this before you prompt AI. Example:

Best guess at organization:

app/ = main application code
app/models/ = database tables
app/routes/ = API endpoints
app/services/ = business logic
tests/ = pytest files
main.py or app/main.py = entry point
Tech stack identified:

FastAPI from requirements.txt
SQLAlchemy for ORM
Pydantic for validation
uvicorn as ASGI server
pytest for testing
Main components guess:

Entry point: uvicorn app.main:app --reload
Core: Task model, CRUD routes for /tasks
2. Apply the Project Structure Prompt
Copy this template and fill in your actual findings:

Code
I'm a junior developer who just joined this Task Manager project. I've read the README but still need help understanding the project structure and technology stack.

Here's my current understanding:
- It seems to be a REST API for managing tasks/todos
- It appears to use FastAPI, SQLAlchemy, Pydantic, uvicorn
- The folder structure seems to follow layered architecture: routes -> services -> models

Project structure:
app/
├── main.py
├── models/
│   └── task.py
├── routes/
│   └── tasks.py
├── services/
├── db.py
└── schemas.py
tests/
requirements.txt
README.md

Key configuration files:
requirements.txt:
fastapi==0.104.1
uvicorn==0.24.0
sqlalchemy==2.0.23
pydantic==2.5.0

Could you:
1. Validate my understanding and correct any misconceptions
2. Identify additional key technologies, frameworks, and libraries used
3. Explain what each main folder likely contains and its purpose
4. Point out where the application entry points are located
5. Suggest 3-5 specific questions I should ask my team to deepen my understanding

I'm particularly confused about the difference between models/ and schemas/.

After your explanation, could you suggest a small exploration exercise I could do to verify my understanding of the project structure?

33 lines hidden
3. Document your findings - example output
Misconceptions I had:

Thought services/ was required. Turns out business logic is currently in routes. services/ is empty scaffold.
Thought schemas/ was for DB. It’s actually Pydantic models for API request/response. models/ is SQLAlchemy DB tables.
Important entry points identified:

app/main.py - creates FastAPI() app, includes routers
uvicorn app.main:app --reload - dev command from README
Architectural pattern: Layered architecture, not MVC. Flow: routes/ calls services/ calls models/. No views/templates since it’s API-only.

Key components + responsibilities:

Component

Responsibility

app/main.py

App factory, middleware, router registration

app/models/task.py

SQLAlchemy DB table definition

app/schemas/task.py

Pydantic models for API validation

app/routes/tasks.py

HTTP endpoints: GET/POST/PUT/DELETE /tasks

app/db.py

get_db dependency for SQLAlchemy sessions

Exercise Part 2: Finding Feature Implementation
Scenario: Add "Task Export to CSV"

1. Initial search + hypothesis
Search terms used: export, csv, file, download, stream
Files found: None. grep -r "csv" app/ returns nothing. No export exists.
Hypothesis: Should add GET /tasks/export in app/routes/tasks.py. CSV logic belongs in new app/utils/csv_export.py to keep routes thin. Will reuse Task model + existing get_db dependency.

2. Apply the Feature Location Prompt
Code
I need to work on "Task Export to CSV" in this Task Manager codebase, but I'm not sure where the code for this feature should live.

My approach so far:
- I've searched for keywords like export, csv, download, file
- I looked in app/routes/ and app/utils/ which seemed relevant  
- I think the feature might relate to the existing GET /tasks endpoint since it already fetches all tasks
- No existing export functionality found

Project structure:
app/
├── routes/tasks.py    # has GET /tasks
├── models/task.py     # Task DB model
├── utils/             # currently empty

Based on my search, these files might be relevant, but I'm not sure:
app/routes/tasks.py - already handles task listing

Can you help me:
1. Evaluate my search approach and suggest improvements
2. Identify which files and directories most likely should contain the implementation
3. Suggest specific search terms or patterns that would be more effective
4. Explain what parts of the feature might be located in different areas of the codebase
5. Recommend a step-by-step investigation process to understand the complete feature flow

Also, what questions could I ask myself as I'm exploring the code to ensure I'm on the right track?

20 lines hidden
3. Document findings - example plan
Where to implement:

app/utils/csv_export.py - New file: def tasks_to_csv(tasks: List[Task]) -> str
app/routes/tasks.py - New endpoint: @router.get("/export") returning StreamingResponse
Related components affected: None. Purely additive. Reuses Task SQLAlchemy model and get_db dependency.

Implementation plan:

Query tasks: db.query(Task).all() using existing DB session
Convert: Use Python csv module + io.StringIO to build CSV in memory
Return: StreamingResponse(iter([csv_string]), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=tasks.csv"})
Test: Hit /docs, try export, open in Excel
Part 3: Understanding Domain Model
1. Extract domain model - example
Core entities found in app/models/task.py:

Python
class TaskStatus(str, Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress" 
    DONE = "done"
    ABANDONED = "abandoned"

class TaskPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class Task(Base):
    id: int
    title: str
    description: str
    status: TaskStatus
    priority: TaskPriority
    due_date: datetime
    user_id: int

14 lines hidden
Business logic found: Task.is_overdue property: due_date < datetime.utcnow() and status != DONE

Confusion: What’s semantic difference between ABANDONED vs DONE? When is a task abandoned?

2. Apply the Domain Understanding Prompt
Code
I'd like you to act as a senior developer who deeply understands our Task Manager domain model. I'm a junior developer trying to make sense of the business logic.

Here's what I've found in the codebase:
[Paste Task, TaskStatus, TaskPriority models + is_overdue method]

Based on this code, my current understanding is:
- The system models personal/work tasks with status and priority
- TaskStatus represents lifecycle: TODO -> IN_PROGRESS -> DONE/ABANDONED  
- I'm confused about when ABANDONED should be used vs just deleting
- Priority seems to only affect UI sorting, no business rules yet
- is_overdue means past due_date but not DONE

Could you, as a senior developer:
1. Validate my current understanding, correcting any misconceptions
2. Help me recognize the core domain concepts represented in this code
3. Explain the relationships between these entities in business terms
4. Clarify what ABANDONED means in this domain
5. Help me connect these models to actual user-facing features

Then, please ask me 3-5 questions that would test my understanding of this domain model.

Finally, suggest a simple diagram I could sketch to visualize these relationships.

17 lines hidden
3. Test knowledge + glossary
Glossary after AI feedback:

Task: Unit of work with lifecycle, belongs to one User
ABANDONED: Terminal state for tasks given up on. Kept for history/audit, unlike delete
Overdue: due_date passed + not in DONE or ABANDONED. Requires user action
Priority: User-set urgency. Currently UI hint only, no auto-behavior
Part 4: Practical Application
Scenario: "Tasks overdue >7 days → ABANDONED unless HIGH priority"

Planning answers:

1. Files to modify:

app/models/task.py - Add is_abandonment_candidate() method
app/services/task_service.py - New file: async def abandon_old_tasks(db)
app/main.py - Add scheduler with APScheduler or FastAPI lifespan + background task
tests/test_task_service.py - Test the rule
2. Outline changes:

Python
# app/models/task.py
def is_abandonment_candidate(self) -> bool:
    if self.priority == TaskPriority.HIGH:
        return False  # High priority tasks never auto-abandon
    days_overdue = (datetime.utcnow() - self.due_date).days
    return self.is_overdue and days_overdue > 7

app/services/task_service.py  

async def abandon_old_tasks(db: AsyncSession):
    result = await db.execute(select(Task).where(Task.status != TaskStatus.DONE))
    tasks = result.scalars().all()
    for task in tasks:
        if task.is_abandonment_candidate():
            task.status = TaskStatus.ABANDONED
    await db.commit()

10 lines hidden
3. Questions for team:

Should this run daily at midnight or be triggered manually?
Do we email users when we auto-abandon their tasks?
Is "7 days" business days or calendar days?
Should we log abandonment reason for audit?
Reflection answers:

How did AI prompts help? The "Feature Location" prompt told me business logic goes in services/, not routes. Would have put it in endpoint otherwise.
Still unsure about: How AsyncSession transactions work. If commit() fails halfway, are some tasks abandoned?
Next steps: Read SQLAlchemy async docs. Add logging to see when job runs. Ask senior dev to review transaction handling.